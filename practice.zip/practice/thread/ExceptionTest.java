package com.fis.practice.thread;

public class ExceptionTest {
// how to handle exception in thread
	public static void main(String[] args) {
		Thread.UncaughtExceptionHandler h = new Thread.UncaughtExceptionHandler() {
			@Override
			public void uncaughtException(Thread t, Throwable e) {
				System.out.println("Eception:"+ e.getMessage());
			}
		};
		
		Runnable run = new Runnable() {
			
			@Override
			public void run() {

				//System.out.println(10/0);
				for(int i = 0 ;i< 10 ;i ++)
				System.out.println(i);
							
			}
		};
		Thread t = new Thread(run, "thread1");
		t.setUncaughtExceptionHandler(h);
		t.start();
		Thread t1 = new Thread(run, "thread2");
		t1.setUncaughtExceptionHandler(h);
		t1.start();
		

	}

}
