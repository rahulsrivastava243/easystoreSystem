package com.fis.practice.thread;

public class DaemonTest {

	public static void main(String[] args) {
		Thread daemon = new Thread(()
				  -> System.out.println("Hello from daemon!"));
				daemon.setDaemon(true);
				daemon.start();
				System.out.println("rahul ");
				System.out.println("rahul ");
				System.out.println("rahul ");
				System.out.println("rahul ");
				System.out.println("rahul ");
				System.out.println("rahul ");
				for(int i =0 ;i < 100 ; i++){
					System.out.println(i);
				}
	}

}
