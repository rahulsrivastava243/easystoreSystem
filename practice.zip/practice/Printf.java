package com.fis.practice;

public class Printf {

	public static void main(String[] args) {
		 String str="java printf double";
	     double variable = 12.248123123;   
	        System.out.println ("String is "+str);
	        System.out.printf ("String is %s", str);
	        System.out.printf("%.2f", variable);  // take the 2 decimal point
	}

}
