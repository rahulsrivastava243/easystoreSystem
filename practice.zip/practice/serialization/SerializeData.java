package com.fis.practice.serialization;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

public class SerializeData {

	public static void main(String[] args) throws FileNotFoundException, IOException {
		Person p = new Person(20, "sumit");
		List<Person> list = new ArrayList<Person>();
		ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream("test.txt"));
		
		list.add(new Person(20, "sumit"));
		list.add(new Person(20, "rahul"));
		list.add(new Person(20, "rohit"));
		list.add(new Person(20, "pankaj"));
		
		objectOutputStream.writeObject(list);
		objectOutputStream.flush();
		objectOutputStream.close();
		System.out.println("success");

	}

}
