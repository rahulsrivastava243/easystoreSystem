package com.fis.practice;


public class VowelCounter {
	

	public static void main(String args[]) { 
	
	System.out.println(vowelCounter("rahul srivastava"));
	}
	
	
	public static int vowelCounter(String value){
		int count = 0;
		char[] letters = value.toCharArray(); 
		for (char c : letters) {
			switch (c) { 
			case 'a': 
			case 'e': 
			case 'i': 
			case 'o': 
			case 'u': 
				count++; 
			break; 
			default: 
			}
		}
		return count;
	}
}
	


