package com.fis.practice;

public class Palindrom {

	public static void main(String[] args) {
		System.out.println(isPalindrom("jahaj"));

	}
	
	public static  boolean isPalindrom(String value){
		return value.equalsIgnoreCase(new StringBuilder(value).reverse().toString());
	}

}
