package com.fis.practice;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;

public class ThreadTest {
 
                public static void main(String[] args) throws InterruptedException, ExecutionException {
 
                                Semaphore mutex = new Semaphore(1, true);
                                // PrintThread sharedObject = new PrintThread(mutex);
                                PrintCallable obj = new PrintCallable();
                                ExecutorService service = Executors.newFixedThreadPool(3);
                                for (int i = 1; i <= 100; i++) {
 
                                                service.submit(obj).get();
 
                                }
                                service.shutdown();
                }
 
}
 
class PrintCallable implements Callable<Boolean> {
                int count = 0;
 
                public Boolean call() throws Exception {
                                System.out.println(Thread.currentThread().getName() + "---" + (++count));
                                return true;
 
                }
 
}
 
class PrintThread implements Runnable {
                int count = 0;
                Semaphore mutex;
 
                public PrintThread(Semaphore c) {
                                this.mutex = c;
                }
 
                public void run() {
                                try {
                                                mutex.acquire();
                                                Thread.sleep(5);
                                                System.out.println(Thread.currentThread().getName() + "---" + (++count));
                                                mutex.release();
 
                                } catch (InterruptedException e) {
                                                e.printStackTrace();
                                }
 
                }
 
}