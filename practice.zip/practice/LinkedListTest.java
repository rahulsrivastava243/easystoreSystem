package com.fis.practice;

import java.util.LinkedList;

public class LinkedListTest {

	public static void main(String[] args) {
		LinkedList<Integer> train = new LinkedList<Integer>();
		train.add(7);
		train.add(8);
		train.add(9);
		train.add(10);
		train.add(11);
		train.add(12);
		train.add(13);
		
		System.out.println(findFirst(train));
		System.out.println(findLast(train));
		
	}

	public static int findFirst(LinkedList<Integer> train){
		return train.getFirst();
	}
	
	public static int findLast(LinkedList<Integer> train){
		return train.getLast();
	}
}
