package com.fis.practice;

public class LargestElement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	
	public static int secoundLargest(Integer[] values){
		int i , first , second ;
		if(values.length <= 2){
			System.out.println("Invalid input");
			return 0;
		}
		
			first = second = Integer.MIN_VALUE;
			for(i = 0 ;i < values.length ; i++){
				
				if( values[i] >= first){
					second = first;
					first = values[i];
				}
				else if(values[i] > second && values[i] != first){
					second = values[i];
				}
			}
			
			if(second == Integer.MIN_VALUE){
				System.out.println("There is no second value in this array.");
			}
			else{
				System.out.println("second largest element : "+second);
				
			}
		
		return 1;
	}

}
