package com.fis.practice;

import java.text.DecimalFormat;

public class RoundDecimal {
    /**
     * java round double to 2 decimal places
     * @author www.instanceofjava.com
     */
    public static void main(String[] args) {
        
        double number = 12.3712377;
        DecimalFormat df1 = new DecimalFormat("#.##");
        System.out.println(number + " is rounded to: " + df1.format(number));
         
        DecimalFormat df2 = new DecimalFormat("#.###");
        System.out.println(number + " is rounded to: " + df2.format(number));
         
        number = 12.388654;
        
        DecimalFormat df3 = new DecimalFormat("#.##");
        System.out.println(number + " is rounded to: " + df3.format(number));
       
        
        DecimalFormat df4 = new DecimalFormat("#.###");
        System.out.println(number + " is rounded to: " + df4.format(number));
        
        System.out.println(new DecimalFormat("0.0000").format(number));  //# and 0 both r fine
        
        System.out.println(round(123.3423432,2));
 
    }
    
    public static double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        long factor = (long) Math.pow(10, places);
        value = value * factor;
        long tmp = Math.round(value);
        return (double) tmp / factor;
    }
 
}