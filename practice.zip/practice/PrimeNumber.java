package com.fis.practice;

public class PrimeNumber {

	public static void main(String[] args) {
		PrimeNumber number = new PrimeNumber();
		number.printPrime(50);
		System.out.println(number.isPrime(49));

	}

	public void printPrime(int end) {
		int count = 0;
		for (int i = 2; i <= end; i++) {
			count = 0;
			for (int j = 2; j <= i / 2; j++) {
				if (i % j == 0) {
					count++;
					break;
				}
			}
			if (count == 0) {
				System.out.println(i);
			}
		}
	}
	
	boolean isPrime(int n) {
	    //check if n is a multiple of 2
	    if (n%2==0) return false;
	    //if not, then just check the odds
	    for(int i=3;i*i<=n;i+=2) {
	        if(n%i==0)
	            return false;
	        else
	        	System.out.println(i);
	    }
	    return true;
	}
}
