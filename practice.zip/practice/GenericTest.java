package com.fis.practice;

import java.util.ArrayList;
import java.util.List;

public class GenericTest {
	
	public static void main(String[] args) {
		List<Object> listObj = new ArrayList<>();
		List<String> listString = new ArrayList<>();
		listObj.add("rahul");
		listObj.add("rohit");
		listObj.add("rahul");
		listObj.add("rahul");
		
		
		listString.add("rahul");
		listString.add("rohit");
		listString.add("rahul");
		listString.add("rahul");
		
		listObj.addAll(listObj);
		//listObj =listString
		
	}

}
