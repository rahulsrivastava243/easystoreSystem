package com.fis.practice.producerConsumerProblem;

import java.util.Vector;


public class Producer1 implements Runnable {
	
	private final Vector<Integer> sharedQueue;
	private int SIZE = 0;
	
	public Producer1(Vector<Integer> sharedQueue , int size){
		this.sharedQueue = sharedQueue;
		this.SIZE = size;
	}
	

	@Override
	public void run() {
		for(int i = 0; i <= 10 ;i++){
			System.out.println("produce :" + i);
			try {
				produce(i);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}
	
	
	private void produce(int i) throws InterruptedException{
		while (sharedQueue.size() == SIZE) {

			synchronized (sharedQueue) {
				System.out.println(
						"Queue is full:" + Thread.currentThread().getName() + "queue size : " + sharedQueue.size());

				sharedQueue.wait();
			}
		}
		
		synchronized(sharedQueue){
			sharedQueue.addElement(i);
			sharedQueue.notifyAll();
		}
	}

}
