package com.fis.practice.producerConsumerProblem;

import java.util.Vector;

public class Consumer1 implements Runnable {
	
	private Vector<Integer> sharedQueue;
	private int SIZE = 0;
	
	public Consumer1(Vector<Integer> sharedQueue,int SIZE){
		this.sharedQueue = sharedQueue;
		this.SIZE = SIZE;
	}
	
	@Override
	public void run() {
		while(true){
			try{
				 System.out.println("Consumed: " + consume());
				Thread.sleep(50);
			}
			catch(Exception e){
				
			}
		}
		
	}

	private int consume() throws InterruptedException {
        //wait if queue is empty
        while (sharedQueue.isEmpty()) {
            synchronized (sharedQueue) {
                System.out.println("Queue is empty " + Thread.currentThread().getName()
                                    + " is waiting , size: " + sharedQueue.size());

                sharedQueue.wait();
            }
        }

        //Otherwise consume element and notify waiting producer
        synchronized (sharedQueue) {
            sharedQueue.notifyAll();
            return (Integer) sharedQueue.remove(0);
        }
    }


}
