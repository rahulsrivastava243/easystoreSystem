package com.fis.practice.producerConsumerProblem;

import java.util.Vector;

public class ProducerConsumerSolutionWithWaitNotify {

	public static void main(String[] args) {
		Vector<Integer> vector = new Vector<>();
		int size = 4;
		Thread producuer = new Thread(new Producer1(vector, size),"Producer");
		Thread consumer = new Thread(new Consumer1(vector, size),"Consumer");
		producuer.start();
		consumer.start();
	}
}
