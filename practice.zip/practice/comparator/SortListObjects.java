package com.fis.practice.comparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SortListObjects {
 
     public static void main(String[] args){
        
        
        List<Student> studentlst= new ArrayList<Student>();
        
        studentlst.add(new Student("Saisesh",1,80));
        studentlst.add(new Student("Vinod",4,70));
        studentlst.add(new Student("Ajay",3,95));
        
        System.out.println("** Before sorting **:");
         
        for (Student student : studentlst) {
            System.out.println(student);
        }
     //   Collections.sort(studentlst);  // using comparable
       // Collections.sort(studentlst,new NameComparator());
      //  Collections.sort(studentlst,new RollNoComparator());
       // Collections.sort(studentlst,new MarksComparator());
        Collections.sort(studentlst,(obj1,obj2) -> obj1.getName().compareTo(obj2.getName()));
        
        
        System.out.println("** After sorting **");
         
        for (Student student : studentlst) {
            System.out.println(student);
        }
    }
 
}