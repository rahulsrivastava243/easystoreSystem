package com.fis.practice.enumeration;


public enum Enum1 {
	
	EXCEEDS_EXPECTATIONS(6), EXCELLENT(5), SUPERB(4), NICE(3), NEEDS_IMPROVEMENT(2), POOR(1);

	private int value;
	private String name;

	public int getRating() {
		return value;
	}

	private Enum1(int value) {
	  this.value = value;
	 }
	
	
	public String toString() {
        return name;
 }
}
