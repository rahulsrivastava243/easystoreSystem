package com.fis.practice.enumeration;

public enum EnumTest {
	
	;
	
	public static boolean isValid() { 
		throw new UnsupportedOperationException("Not supported yet."); 
		
	}

}
