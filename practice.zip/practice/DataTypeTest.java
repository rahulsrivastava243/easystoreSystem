package com.fis.practice;

public class DataTypeTest {

	public static void main(String[] args) {
		short a= 10;
		short b = 12;
		int c= a + b;
		System.out.println(c);
	}

}
