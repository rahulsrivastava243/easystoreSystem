package com.fis.practice.garbagecollector;

public interface Abc {

}
