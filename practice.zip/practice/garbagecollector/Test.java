package com.fis.practice.garbagecollector;
public class Test
{
    
        public Test()
        {
        	try
            {
            System.out.println("GeeksforGeeks");
            throw new Exception();
            }
            catch(Exception e)
            {
                System.out.println("GFG");
            }
        
    }
   
    public static void main(String[] args)
    {
        Test test = new Test();
    }
}