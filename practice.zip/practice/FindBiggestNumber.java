package com.fis.practice;

public class FindBiggestNumber {

	public static void main(String[] args) {
		System.out.println(find(52,17));

	}
	
	
	public static int find(int a,int b){
		return Math.max(a, b);
	}

}
