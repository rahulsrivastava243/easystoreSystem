package com.fis.practice.system;

public class Exit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
System.exit(-10);
System.out.println("#############################33");
	}

}
