package com.fis.practice.designpattern;

public class Imuutable1 {
    private final int value;

    public Imuutable1(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
