package com.fis.practice.designpattern;


public class Mutable1 extends Imuutable1{

	 private int realValue;

     public Mutable1(int value) {
         super(value);

         realValue = value;
     }

     public int getValue() {
    	 System.out.println("****Mutable1****");
         return realValue;
     }
     public void setValue1(int newValue) {
         realValue = newValue;
     }
	public static void main(String[] args) {
		 Mutable1 obj = new Mutable1(4);
		 Imuutable1 immObj = (Imuutable1)obj;              
	        System.out.println(immObj.getValue());
	        obj.setValue1(30);
	        System.out.println(immObj.getValue());
		   
	}
	
	
	
}
