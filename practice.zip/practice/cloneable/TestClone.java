package com.fis.practice.cloneable;

public class TestClone {

	public static void main(String[] args) throws CloneNotSupportedException {
		Student s = new Student(new Subject("Computer"),"rahul");
		System.out.println(s);
		Student s1 = s.clone();
		System.out.println(s1);
      
	}

}
