package com.fis.practice.cloneable;

public class TestShallowCopy implements Cloneable{

	private int age;
	private String name;
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public TestShallowCopy(int age, String name) {
		super();
		this.age = age;
		this.name = name;
	}
	
	
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TestShallowCopy [age=" + age + ", name=" + name + "]";
	}
	public static void main(String[] args) throws CloneNotSupportedException {
		TestShallowCopy testShallowCopy = new TestShallowCopy(28, "rahul");
		System.out.println(testShallowCopy);
		TestShallowCopy copy = (TestShallowCopy)testShallowCopy.clone();
		System.out.println(copy);
		copy.setAge(35);
		System.out.println(testShallowCopy);
		System.out.println(copy);
	}
	
	
}
