package com.fis.practice.cloneable;

public class Student implements Cloneable{

	private Subject sub;
	private String name;
	public Student(Subject sub, String name) {
		super();
		this.sub = sub;
		this.name = name;
	}
	public Subject getSub() {
		return sub;
	}
	public void setSub(Subject sub) {
		this.sub = sub;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Student [sub=" + sub + ", name=" + name + "]";
	}
	
	@Override
	public Student clone()throws CloneNotSupportedException{
		return (Student)super.clone();
	}
	
}
