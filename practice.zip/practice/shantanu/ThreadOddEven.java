package com.fis.practice.shantanu;
public class ThreadOddEven {

	public static void main(String args[]) {

		Print print = new Print();
		Thread t1 = new Thread(new NumberHelper(print, true), "ThreadEven");
		Thread t2 = new Thread(new NumberHelper(print, false), "ThreadOdd");

		t1.start();
		t2.start();
	}

}

class NumberHelper implements Runnable {

	Print print;
	boolean evenThread;

	public NumberHelper(Print print, boolean flag) {
		this.print = print;
		this.evenThread = flag;
	}

	public void run() {
		try {
			int i = evenThread ? 2 : 1;
			for (; i < 20;) {
				if (i % 2 == 0) {
					print.even(i);
				} else {
					print.odd(i);
				}
				i = i + 2;
			}

		} catch (Exception e) {

		}
	}
}

class Print {

	boolean printOdd = true;

	public synchronized void odd(int i) throws Exception {
		if (!printOdd) {
			wait();
		}
		System.out.println(Thread.currentThread().getName() + " - " + i);
		printOdd = false;
		notifyAll();

	}

	public synchronized void even(int i) throws Exception {
		if (printOdd) {
			wait();
		}
		System.out.println(Thread.currentThread().getName() + " - " + i);
		printOdd = true;
		notifyAll();

	}
}