package com.fis.practice.shantanu;

public class Core {
	public static void main(String[] args) {
		
		
//		System.out.println(oddNumbers(3,9));
		System.out.println(checkCharacterRotation("abc", "bca"));

	}

	private static boolean checkCharacterRotation(String s1, String s2) {
		boolean isEqual = false;
		char[] ary1 = s2.toCharArray();
		if (s1.length() == s2.length()) {
			for (int i = 0; i < ary1.length; i++) {
				s2 = (s2 + ary1[i]);
				if (s2.substring(s2.length() - s1.length(), s2.length()).equalsIgnoreCase(s1)) {
					isEqual = true;
					break;
				}
			}
		}
		return isEqual;
	}

	private static void printCombinations(String s) {
		
	}

	static int[] oddNumbers(int l, int r) {
		int startPoint = l % 2 == 0 ? l + 1 : l;
		int endPoint = r % 2 == 0 ? r - 1 : r;
		int[] oddArray =  new int[((endPoint -startPoint)/2)+1];
		int j = 0;
		for (int i = startPoint; i <= endPoint;) {
			oddArray[j] = i;
			i = i + 2;
			++j;
		}
		return oddArray;
	}
}