
package com.fis.practice.shantanu;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

/* 'n' independent threads will perform their task and will wait at CyclicBarrier. 
 * Once reached, one thread will execute the action linked with Barrier. 
 * These n threads will continue executing their independent task and will wait 
 * for other barriers if there.  
 */
public class CyclicBarrierTest {

	public static void main(String[] args) {
		//This will get executed once barrier1 is crossed.
		Runnable barrier1Action = new Runnable() {
			public void run() {
				System.out.println(Thread.currentThread().getName()+ " - BarrierAction 1 executed ");
			}
		};
		
		//This will get executed once barrier2 is crossed.
		Runnable barrier2Action = new Runnable() {
			public void run() {
				System.out.println(Thread.currentThread().getName()+ " - BarrierAction 2 executed ");
			}
		};

		//These cyclicbarrier will wait for two threads.
		CyclicBarrier barrier1 = new CyclicBarrier(2, barrier1Action);
		CyclicBarrier barrier2 = new CyclicBarrier(2, barrier2Action);

		//Independent Task1
		CyclicBarrierRunnable1 barrierRunnable1 = new CyclicBarrierRunnable1(barrier1, barrier2);

		//Independent Task2
		CyclicBarrierRunnable2 barrierRunnable2 = new CyclicBarrierRunnable2(barrier1, barrier2);

		new Thread(barrierRunnable1).start();
		new Thread(barrierRunnable2).start();
	}
}

//One thread will execute this task and will wait at barrier.
class CyclicBarrierRunnable1 implements Runnable {

	CyclicBarrier barrier1 = null;
	CyclicBarrier barrier2 = null;

	public CyclicBarrierRunnable1(CyclicBarrier barrier1, CyclicBarrier barrier2) {
		this.barrier1 = barrier1;
		this.barrier2 = barrier2;
	}

	public void run() {
		try {
			System.out.println("Task 1 is executed by "+Thread.currentThread().getName() + " waiting at barrier 1");
			this.barrier1.await(); 
			
			// following line will not get executed until other thread reaches the barrier.
			System.out.println("Task 1 is executed by "+Thread.currentThread().getName() + " waiting at barrier 2");
			this.barrier2.await();

			System.out.println("Task 1 is executed by "+Thread.currentThread().getName() + " done!");

		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (BrokenBarrierException e) {
			e.printStackTrace();
		}
	}
}

//Other thread will execute this task and will wait at barrier.
class CyclicBarrierRunnable2 implements Runnable {

	CyclicBarrier barrier1 = null;
	CyclicBarrier barrier2 = null;

	public CyclicBarrierRunnable2(CyclicBarrier barrier1, CyclicBarrier barrier2) {
		this.barrier1 = barrier1;
		this.barrier2 = barrier2;
	}

	public void run() {
		try {
			Thread.sleep(5000);
			System.out.println("Task 2 is executed by "+Thread.currentThread().getName() + " waiting at barrier 1");
			this.barrier1.await();

			Thread.sleep(5000);
			System.out.println("Task 2 is executed by "+Thread.currentThread().getName() + " waiting at barrier 2");
			this.barrier2.await();

			System.out.println("Task 2 is executed by "+Thread.currentThread().getName() + " done!");

		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (BrokenBarrierException e) {
			e.printStackTrace();
		}
	}
}