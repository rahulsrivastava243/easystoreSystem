package com.fis.practice;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class SetOperation {

	public static void main(String[] args) {
		
		Set<String> setA =  new HashSet<String>(Arrays.asList("A","B","C","D"));
		Set<String> setB =  new HashSet<String>(Arrays.asList("A","B","C","E"));
		findElementInSetAAndB(setA,setB).forEach(System.out::println);
		findElementInSetANotInB(setA,setB).forEach(System.out::println);
		findUnique(setA,setB).forEach(System.out::println);

	}
	
	public static Set<String> findElementInSetAAndB(Set<String> setA,Set<String> setB){
		System.out.println("The Element in set A that are in set B ");
	    Set<String> common = new HashSet<String>(setA);
	    common.retainAll(setB);
	    
	    return common;
	}
	
	public static Set<String> findElementInSetANotInB(Set<String> setA,Set<String> setB){
		System.out.println("The Element set A that are not in set B");
		setA.removeAll(setB);
	    return setA;
	}
	
	
	public static Set<String> findUnique(Set<String> setA,Set<String> setB){
		System.out.println(" Unique set of all numbers that are in set A or set B.");
		setA.addAll(setB);
	    return setA;
	}
	
	
	

}
