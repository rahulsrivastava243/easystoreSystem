package com.fis.practice.array;

import java.util.Arrays;

public class CheckTwoEqualArray {

	public static void main(String[] args) {
		int[][] arr1 = {{1,2,3},{2,5,4},{5,7,6}};
		int[][] arr2 = {{1,2,3},{2,5,4},{5,7,6}};
        System.out.println(Arrays.deepEquals(arr1, arr2));
        
        int[] ary = {1,2,3,4,5,6};
        int[] ary1 = {1,2,3,4,5,6};
        int[] ary2 = {1,2,3,4};
        System.out.println("Is array 1 equal to array 2?? " +Arrays.equals(ary, ary1));
        System.out.println("Is array 1 equal to array 3?? " +Arrays.equals(ary, ary2));
     
	}

}
