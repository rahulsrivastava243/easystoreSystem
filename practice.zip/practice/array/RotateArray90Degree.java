package com.fis.practice.array;

public class RotateArray90Degree {

	public static void main(String[] args) {
		/*int twoD[][]= new int[4][5]; 
		int i, j, k = 0; 
		for(i=0; i<4; i++) 
		for(j=0; j<5; j++) { 
		twoD[i][j] = k; 
		k++; 
		} 
		
		for(i=0; i<4; i++) { 
			for(j=0; j<5; j++) 
			System.out.print(twoD[i][j] + " "); 
			System.out.println(); 
			} */
		
		int arr1[][]={{1,2,3,4},{2,4,5,7},{4,4,5,8},{2,5,6,1}}; 
		int arr[][] = arr1;
		/*int[][] arr = new int[3][3];
		arr[0][0]=1;  
		arr[0][1]=2;  
		arr[0][2]=3;  
		arr[1][0]=4;  
		arr[1][1]=5;  
		arr[1][2]=6;  
		arr[2][0]=7;  
		arr[2][1]=8;  
		arr[2][2]=9;  */
		
		System.out.println(arr.length);
		for(int i = 0;i < 4 ;i++){
			for(int j=0;j<4 ;j++)
	         	System.out.print(arr[i][j] + "\t");
		System.out.println();
		}
		
		 
		
		/*int arr1[]={4,4,5};  
		  
		Class c=arr1.getClass();  
		String name=c.getName();  
		  
		System.out.println(name); */ 
		  

	}

}
