package com.fis.practice.array;

public class SeconeMinAndMax {

	public static void main(String[] args) {
		int a[] = {2,34,5,23,78,1,34,45};
		int secondHieghest = Integer.MIN_VALUE;
		int secoundLowest = Integer.MAX_VALUE;
		int highest =  Integer.MIN_VALUE;
		int lowest =  Integer.MAX_VALUE;
		for(int i=0;i < a.length ; i++){
			
			if(a[i] > highest){
				secondHieghest = highest;
				highest = a[i];
			}
			else if(a[i] > secondHieghest){
				secondHieghest = a[i];
			}
			
			
			if(a[i] < lowest){
				secoundLowest = lowest;
				lowest = a[i];
			}
			else if(a[i] < secoundLowest){
				secoundLowest = a[i];
			}
		}
		
		System.out.println("highest="+highest);
		System.out.println("secondHieghest="+secondHieghest);
		System.out.println("lowest="+lowest);
		System.out.println("secoundLowest="+secoundLowest);

	}

}
