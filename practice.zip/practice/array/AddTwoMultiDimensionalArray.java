package com.fis.practice.array;

public class AddTwoMultiDimensionalArray {

	public static void main(String[] args) {
		int[][] arr1 = {{1,2,3},{2,5,4},{5,7,6}};
		int[][] arr2 = {{3,4,5},{5,6,7},{5,3,8}};
		
		
		for(int i= 0 ;i <3 ;i++){
			for(int j=0 ;j<3; j++){
				arr2[i][j] = arr1[i][j] + arr2[i][j];
				System.out.print(arr2[i][j] + "\t");
			}
			System.out.println();
		}

	}

}
