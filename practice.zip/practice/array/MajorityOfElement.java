package com.fis.practice.array;

import java.util.Arrays;

public class MajorityOfElement {

	public static void main(String[] args) {
		int a[] = {2,3,3,4,5,2,2,4,5,1,2};
         System.out.println(new MajorityOfElement().majorityElement(a));
	}
	
	public int majorityElement(int[] num) {
		if (num.length == 1) {
			return num[0];
		}
	 
		Arrays.sort(num);
		return num[num.length / 2];
	}

}
