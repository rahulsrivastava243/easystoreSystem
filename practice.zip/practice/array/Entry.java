package com.fis.practice.array;
class Entry {
    Object key;
    String value;
    Entry next;
 
    Entry(Object k, String v) {
        key = k;
        value = v;
    }
 
    public String getValue() {
        return value;
    }
 
    public void setValue(String value) {
        this.value = value;
    }
 
    public Object getKey() {
        return key;
    }
}