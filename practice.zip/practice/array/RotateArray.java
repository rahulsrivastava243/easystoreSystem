package com.fis.practice.array;

public class RotateArray {

	public static void main(String[] args) {
		int[][] arr1 = {{1,2,3},{2,5,4},{5,7,6}};
		int[][] arr2 = new int[3][3];
		
		for(int i= 0 ;i <3 ;i++){
			for(int j=0 ;j<3; j++){
				arr2[i][j] = arr1[j][i];
			}
		}
		
		printArray(arr1);
		System.out.println("\n");
		printArray(arr2);

	}
	
	
	public static void printArray(int[][] arr){
		for(int i= 0 ;i <3 ;i++){
			for(int j=0 ;j<3; j++){
				System.out.print(arr[i][j] + "\t");
			}
			System.out.println();
		}

	}

}
