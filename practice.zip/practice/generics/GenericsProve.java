package com.fis.practice.generics;

import java.util.ArrayList;
import java.util.List;

public class GenericsProve {
	
	public void m1(List<String> list){
		
	}
	
	
   public void m1(List<Integer> list){
		
	}

}
