package com.fis.practice.generics;

import java.util.ArrayList;
import java.util.List;

public class GenericTest<L> {

	public static void main(String[] args) {
		List<?> list = new ArrayList<String>();
		List<?> list1 = new ArrayList<? extends Number>();
		list.add(null);
		
       
	}
	
	
	public static void print(List<?> list){
		list.add(null);
		
	}
	

	public  void print1(List<? extends L> list){
		list.add(null);
		list.add(L);
	}
	
	public  void prin21(List<? super L> list){
		list.add(null);
		list.add(L);
	}

	
	public <T> add (T t){
		
	}
}
