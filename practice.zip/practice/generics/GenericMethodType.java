package com.fis.practice.generics;


public class GenericMethodType {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
new GenericMethodType().add(new Abc());
	}
	
	public <T extends Comparable & Runnable> boolean add(T t){
		return true;
	}
	
	public class Abc implements Comparable,Runnable{

		@Override
		public void run() {
			// TODO Auto-generated method stub
			
		}

		@Override
		public int compareTo(Object o) {
			// TODO Auto-generated method stub
			return 0;
		}

	
	}

}
