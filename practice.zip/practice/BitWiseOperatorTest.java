package com.fis.practice;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BitWiseOperatorTest {

	public static void main(String[] args) {
		System.out.println((10 >> 1));
		
		ArrayList<String> list = new ArrayList<>();
		list.add("rahul");
		list.forEach(System.out::println);
		List<String> list1 = (List<String>) list.clone();
		ArrayList<String> list2 = new ArrayList<>();
		 Collections.copy(list2, list);
		list1.forEach(System.out::println);
		list2.forEach(System.out::println);

	}

}
