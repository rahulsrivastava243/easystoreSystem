package com.fis.practice;

import java.util.ArrayList;
import java.util.List;

public class FinalizeTest {

	public static void main(String[] args) throws InterruptedException {
		new FinalizeTest().add();
		Thread.sleep(1000000);
	}
	
	
	public void add() {
		Integer a = 100;
		Integer b = 200;
		List<String> l = new ArrayList<String>();
		System.out.println(100+200);
		
	}
	
	
	@Override
	 protected void finalize() throws Throwable {
		
		System.out.println("hi arhul");
	}

}
