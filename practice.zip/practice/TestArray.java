package com.fis.practice;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class TestArray {

	public static void main(String[] args) {
		int sum = 0 ;
		int[] array = new int[6];
		
		BufferedReader br = null;
		int k= 0 ;

        try {
            br = new BufferedReader(new InputStreamReader(System.in));
            while (array.length <= 6) {
                array[k] = Integer.parseInt(br.readLine());
                k++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        
        
        
		for(int i = 0 ; i < array.length ; i++){
		    sum += array[i];
		}
			System.out.println(sum);


	}

}
