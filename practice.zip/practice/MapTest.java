package com.fis.practice;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class MapTest {

	public static void main(String[] args) {
		Map<Employee, String> m = new HashMap<Employee,String>();
		Employee employee = new Employee();
		System.out.println(employee.age);
		int i[] = {1,2,3}; 
		int[] ab = Arrays.sort(i);
		
	}
	
	

 class Employee{
	
	int age;
	String name ;
	
	public Employee(){
		
	}
	public Employee(int age, String name) {
		super();
		this.age = age;
		this.name = name;
	}
	
	
	
}
	
}



