package com.fis.practice;

public class SwapTwoNumberWithoutTemp {

	public static void main(String[] args) {
		Integer a= 10;
		Integer b =20;
		swap(a,b);
	}
	
	
	public static int swap(Integer a,Integer b){
		a = a + b; //30
		b = a - b; //30-20 =10
		a = a - b; //30-10 = 20
		System.out.println("a= "+ a +"  b="+ b);
		return 0;
	}
	
	public static int swap1(Integer a,Integer b){
		a = a * b; //200
		b = a/b; //200/20 = 10
		a = a/b; //200/10 = 20
		System.out.println("a= "+ a +"  b="+ b);
		return 0;
	}

}
