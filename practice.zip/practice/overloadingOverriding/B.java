package com.fis.practice.overloadingOverriding;

public class B extends A{

	@Override
	public void printName() throws RuntimeException{
		System.out.println("Value - B");
	}
	
	
}
