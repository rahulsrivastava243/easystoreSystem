package com.fis.practice.overloadingOverriding;

public class C extends A{

	public void printName(){
		System.out.println("Value - C");
	}
}
