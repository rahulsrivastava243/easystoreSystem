package com.fis.practice.overloadingOverriding;

public class A {

	public void printName() throws NullPointerException{
		System.out.println("Value - A");
	}
	
	
	private void add(){
		
	}
}
