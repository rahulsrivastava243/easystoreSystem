package com.fis.practice.overloadingOverriding;

public class Parent {
	public Parent(){
		System.out.println("parent constuctor");
	}
	
	{
		System.out.println("parent instance");	
	}
	
	static{
		System.out.println("parent static");
	}
	

}
