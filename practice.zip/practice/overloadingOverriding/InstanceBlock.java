package com.fis.practice.overloadingOverriding;

public class InstanceBlock extends Parent{
	
	static{
		System.out.println("static child");
	}
	
	{
		System.out.println("instance block child");
	}
	
	public InstanceBlock(){
		System.out.println("constructor child");
	}

	public static void main(String[] args) {
		InstanceBlock block = new InstanceBlock();

	}

}
