package com.fis.practice;

import java.io.IOException;

import javax.xml.bind.JAXBException;

public class ThrowsTest {
	
	public int add()throws ArithmeticException,Exception{
		throw new Exception();
		//throw new ArithmeticException();
		
		
	}
	
	public static void main(String[] args) {
		try {
			foo();
		} catch (IOException e) {
			e.printStackTrace();
		}catch(JAXBException e){
			e.printStackTrace();
		}catch(NullPointerException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public static void foo() throws IOException{
		
	}

}
