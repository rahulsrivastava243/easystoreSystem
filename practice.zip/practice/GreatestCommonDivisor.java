package com.fis.practice;

public class GreatestCommonDivisor {

	static int gcd(int a, int b)
    {
        // Everything divides 0 
        if (a == 0 || b == 0)
           return 0;
      
        // base case
        if (a == b)
            return a;
      
        // a is greater
        if (a > b)
            return gcd(a-b, b);
        return gcd(a, b-a);
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int a = 98, b = 56;
	        System.out.println("GCD of " + a +" and " + b + " is " + gcd(a, b));

	}

}
