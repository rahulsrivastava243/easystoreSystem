package com.fis.practice;

import java.text.DecimalFormat;

public class ConvertIntToString {

	public static void main(String[] args) {
		int i = 10;
		System.out.println(new Integer(i).toString());
		System.out.println(String.valueOf(i));
		System.out.println(Integer.toString(i));
		System.out.println(String.format("%d", i));
		DecimalFormat objct = new DecimalFormat("#,###");
		String numberstr1 = objct.format(i);
		System.out.println(numberstr1);
		System.out.println(new StringBuffer().append(i).toString());
		System.out.println(new StringBuilder().append(i).toString());
		System.out.println(i + "");
		System.out.println(Integer.toBinaryString(i));
		System.out.println();

	}

}
