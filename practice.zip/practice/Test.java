package com.fis.practice;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.concurrent.TimeUnit;

public class Test {

	public static void main(String[] args) {
		System.out.println(TimeUnit.DAYS.toMillis(1));
		System.out.println(1 * 24 * 60 * 60 * 1000);
		Calendar cal = Calendar.getInstance();
		int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
		System.out.println(dayOfMonth);
	}
	
	
	public static int numberOfDaysInMonth(int month, int year) {
	    Calendar monthStart = new GregorianCalendar(year, month, 1);
	    return monthStart.getActualMaximum(Calendar.DAY_OF_MONTH);
	}
}
