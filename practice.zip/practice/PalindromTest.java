package com.fis.practice;

public class PalindromTest {

	public static void main(String[] args) {
		System.out.println(getPalindrom("rahul"));
		System.out.println(getPalindrom1("rahul"));
		System.out.println(getPalindrom2("rahul"));
		System.out.println(isPalindrom("545"));

	}
	
	public static boolean isPalindrom(String value){
		if(value.matches("^[0-9]*$")){	
			System.out.println("---------");
			return palindromNumber(Integer.parseInt(value));
		}
		return value.equalsIgnoreCase(getPalindrom2(value));
	}
	
	public static String getPalindrom(String value){
		return new StringBuffer(value).reverse().toString();
	}
	
	public static String getPalindrom1(String value){
		return new StringBuilder(value).reverse().toString();
	}
	
	public static String getPalindrom2(String value){
		String reverse = "";
		for(int i = value.length()-1 ;i>=0 ;i--){
			reverse +=value.charAt(i);
		}
		return reverse;
	}
	
	
	public static boolean palindromNumber(int num){
		int a=0,temp = 0,b= num;
		while(num >0){
			a = num%10;
			num = num/10;
			temp = temp*10 + a;
		}
		
		if(temp == b){
			return true;
		}
		else{
			return false;
		}
	}
	
	

}
