package com.fis.practice;

public class ReverseString {

	 String reverse ="";
	public static void main(String[] args) {
	  System.out.println(reverse("rahul"));

	}
	
	
	public static String reverse(String value){
		if(value == null || value.isEmpty()){
			return value;
		}
		else{
			String reverse = "";
			for(int i = value.length()-1 ; i >= 0 ;i--){
				reverse = reverse + value.charAt(i);
			}
			return reverse;
		}
	}
	
	
	public String reverseString(String str){
        if(str.length() == 1){
            return str;
        } else {
            reverse += str.charAt(str.length()-1)
                    +reverseString(str.substring(0,str.length()-1));
            return reverse;
        }
    }

}
