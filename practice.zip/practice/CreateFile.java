package com.fis.practice;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

public class CreateFile {

	public static void main(String[] args) throws IOException {
		 File file = new File("C:\\Users\\Rahuls1\\Desktop\\abcd\\rahul.txt");
String a ="asdf asdfa adsfas assdfa sdfasd asdfa asfasdf aasfasf \n fdfasef asfda asfd \t adadfa \n asdf asd asfas sff asdf"
		+ "asdfa sdfa sfdadfas\n assfs \n afasd \na fasfasf \n afadasdfsa ffasdfasfd sdf dfafaas\n asefasf"
		+ "\t asdfa  \n addfa \n asfa ";
          if (!file.exists()) {
        	  file.createNewFile();
          }
              FileOutputStream fos = new FileOutputStream(file);
              PrintStream ps = new PrintStream(fos);
              ps.println(a);
          
		 System.out.println(file.getAbsolutePath());
	}

}
