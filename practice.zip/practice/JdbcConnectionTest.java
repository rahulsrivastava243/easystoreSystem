package com.fis.practice;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcConnectionTest {

		public static void main(String[] args) throws SQLException {
			System.out.println("-------- MySQL JDBC Connection Testing ------------");

			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				System.out.println("Where is your MySQL JDBC Driver?");
				e.printStackTrace();
				return;
			}

			System.out.println("MySQL JDBC Driver Registered!");
			Connection connection = null;

			try {
				connection = DriverManager
				.getConnection("jdbc:mysql://192.168.235.129:3306/test","root", "cloudera");

			} catch (SQLException e) {
				System.out.println("Connection Failed! Check output console");
				e.printStackTrace();
				return;
			}

			if (connection != null) {
				System.out.println("You made it, take control your database now!");
			} else {
				System.out.println("Failed to make connection!");
			}
			
			Statement st = connection.createStatement();
			ResultSet result = st.executeQuery("select * from emp");
			while(result.next()){
				System.out.println(result.getString(1));
				System.out.println(result.getString(2));
			}
			
			
		  }
		


	}

