package com.fis.practice;

public class StringPermutation {

	public static void main(String[] args) {
		String s = "abc";
		int len = s.length();
		char[] cs = s.toCharArray();
		for(int i=0;i<=len-1;i++){
			char ch = cs[0];
			for(int j=0;j<=len-2;j++){ 
				cs[j] = cs[j+1] ;
				cs[j+1] = ch;
				System.out.println(cs);
			
			}
		}
}
	
}
