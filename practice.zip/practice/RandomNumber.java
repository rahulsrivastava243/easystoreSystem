package com.fis.practice;

import java.util.Random;

public class RandomNumber {

	public static void main(String[] args) {

		Random r = new Random();
		int Low = 10;
		int High = 100;
		int result = r.nextInt(High-Low) + Low;
		System.out.println(result);
		System.out.println(r.nextBoolean());
	}

}
