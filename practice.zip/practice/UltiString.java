package com.fis.practice;
public class UltiString {

	public static void main(String[] args) {
		String s = "hgcfhnfxdhghgs";
		char c[] = s.toCharArray();
		char ch[] = s.toCharArray();
		int len = s.length()-1;
		int val = 2;
		for(int i=val;i<=len;i++){
				c[i-val] = c[i];
		}
		int length = val;
		for(int i=len;i>len-val;i--){
			c[i] = ch[--length];
		}
		System.out.println(c);
	}
}