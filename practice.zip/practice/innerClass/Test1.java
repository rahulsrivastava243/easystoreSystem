package com.fis.practice.innerClass;

import java.io.Serializable;

public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	
	public class test2 extends Thread implements Serializable , Cloneable{
		
	}

}
