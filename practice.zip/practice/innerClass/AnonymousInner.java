package com.fis.practice.innerClass;

public class AnonymousInner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
