package com.fis.practice.file;

import java.io.File;
import java.io.IOException;

public class CreateNewFile {

	public static void main(String[] args) throws IOException {
		File file = new File("D:\\ecom\\Practice\\MyPractice\\src\\com\\fis\\practice\\file\\abc.txt");
	    boolean flag = file.createNewFile();
	    System.out.println(flag);
	    File file = new File("D:\\ecom\\Practice\\MyPractice\\src\\com\\fis\\practice\\file\\abc.txt");
	    
	    if(file.renameTo(newFile)){
            System.out.println("File rename success");;
        }else{
            System.out.println("File rename failed");
        }
	    boolean isDeleted = file.delete();
	    System.out.println(isDeleted);
	}

}
