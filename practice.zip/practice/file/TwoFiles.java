package com.fis.practice.file;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.SequenceInputStream;

public class TwoFiles
{
  public static void main(String args[]) throws IOException
  {
    FileInputStream fistream1 = new FileInputStream("D:\\ecom\\Practice\\MyPractice\\src\\com\\fis\\practice\\file\\first.txt");  // first source file
    FileInputStream fistream2 = new FileInputStream("D:\\ecom\\Practice\\MyPractice\\src\\com\\fis\\practice\\file\\secound.txt");  //second source file
 
    SequenceInputStream sistream = new SequenceInputStream(fistream1, fistream2);  
    FileOutputStream fostream = new FileOutputStream("D:\\ecom\\Practice\\MyPractice\\src\\com\\fis\\practice\\file\\Result.txt");        // destination file
 
    int temp;
    while( ( temp = sistream.read() ) != -1)
    {
      System.out.print( (char) temp ); // to print at DOS prompt
      fostream.write(temp);	// to write to file
    }
    fostream.close();
    sistream.close();
    fistream1.close();
    fistream2.close();
   }
}