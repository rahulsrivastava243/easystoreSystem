package com.fis.practice.String;

public class CheckStringSequenceinString {

	public static void main(String[] args) {
		String s1 = "abcdefghijklmnop";
		String s2 = "zcghopa";
		System.out.println(check(s1,s2));
		
	}
	
	
	public static boolean check(String s1 , String s2){
		
		char s11[] = s1.toCharArray();
		char s22[] = s2.toCharArray();
		int start = 0;
		boolean flag = false;
		for(int i =0 ;i < s22.length-1 ; i++){
			for(int j = start ; j <= s11.length-1 ; j++){
				if(s22[i] == s11[j]){
					start = j;
					flag = true;
					break;
				}
				else{
					flag = false;
				}
			}
		}
		
		return flag;
	
	}

}
