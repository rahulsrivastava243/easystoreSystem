package com.fis.practice.polymorphism;

public class Main {

	public static void main(String[] args){
		Super s = new Sub();
		s.sum();
		s.sub();
		Sub sub = new Sub();
		sub.sum();
		sub.sub();
		Super super_ = new Super();
		super_.sum();
		super_.sub();
	}
}
