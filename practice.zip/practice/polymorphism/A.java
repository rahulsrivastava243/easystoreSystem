package com.fis.practice.polymorphism;

public class A {
	
	
	private void add(){
		
	}

	
	public static void m(){
		
	}
	
	final public void sub(){
		
	}
}
