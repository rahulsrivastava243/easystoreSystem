package com.fis.practice.polymorphism;
public class MainClass 
{
    void method(int ... a)
    {
        System.out.println(1);
    }
     
    void method(int[] a)
    {
        System.out.println(2);
    }
}