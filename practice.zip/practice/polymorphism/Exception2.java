package com.fis.practice.polymorphism;

import java.io.FileNotFoundException;
import java.io.IOException;

public class Exception2 extends Exception1{

	public void show()throws IOException{
		
	}
}
