package com.fis.practice.polymorphism;

import java.io.FileNotFoundException;

public class Exception1 {

	
	public void show(){
		
	}
}
