package com.fis.practice.polymorphism;

public class C {
	
	public static void main(String[] args) {
		A a = new A();
		
		A a1 = new B();
		B b1 = new A();
		
		I i = new B();
		
		
	}

}
