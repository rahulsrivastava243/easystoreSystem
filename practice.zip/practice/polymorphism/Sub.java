package com.fis.practice.polymorphism;

public class Sub extends Super{

	 public void sum(){
		 System.out.println("Sub:sum");
	 }
	 
	 public static void sub(){
		 System.out.println("Sub:sub");
	 }
}
