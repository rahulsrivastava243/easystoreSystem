package com.fis.practice.polymorphism;


public class B extends A implements I{
	
	
	
public static void m(){
		
	}


protected void add(){
	
}


public void sub(){
	
}


}
