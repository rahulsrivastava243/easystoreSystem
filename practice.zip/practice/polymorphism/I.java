package com.fis.practice.polymorphism;

public interface I {

}
