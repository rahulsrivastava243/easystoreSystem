package com.fis.practice.polymorphism;

public class Super {

 public void sum(){
	 System.out.println("Super:sum");
 }
 
 public static void sub(){
	 System.out.println("Super:sub");
 }
 
 
}
