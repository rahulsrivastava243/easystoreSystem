package com.fis.practice.polymorphism;

public class OverloadingTest {

	public void m1(){
		
	}
	
	public static void m1(int m1){
		
	}
}
