package com.fis.practice;

import java.io.IOException;

import javax.xml.bind.JAXBException;

public class ExceptionTest {
	public static void main(String[] args) {
		try {
			foo();
		} catch (IOException | JAXBException f) {
			f = new Exception("");
			f.printStackTrace();
		}catch(Exception e){
			e = new Exception("");
			e.printStackTrace();
		}
	}

	public static void foo() throws IOException, JAXBException{
		
	}
}
