package com.fis.practice.exception;

public class A {
	
	public void method() throws Exception{
		try{
			throw new NullPointerException("1");
		}
		catch(Exception e){
			throw new Exception("2");
		}
		finally{
			throw new Exception("3");
		}
	}
	
	public static void main(String[] args) throws Exception {
		new A().method();
	}

}
