package com.fis.practice;
public class RemoveVowels {
 
    /**
     * @www.instanceofjava.com 
     * @String interview programs asked in interviews
     * @Remove vowels from a string in java
     */
 
 public static void main(String[] args) {
 
       // String str = "RemoveVowels";
        String str = "my name is rahul srivastava";
        String resustr = str.replaceAll("[aeiouAEIOU]", "");
        System.out.println(resustr);
 
    }
 
}