package com.fis.practice;

import java.time.LocalDate;

public class DateFormate {

	public static void main(String[] args) {
		LocalDate today = LocalDate.now();
		System.out.println("Current Date="+today);

	}

}
