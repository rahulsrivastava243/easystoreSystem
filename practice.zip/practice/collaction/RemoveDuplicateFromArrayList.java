package com.fis.practice.collaction;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class RemoveDuplicateFromArrayList {

	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(new Integer[]{12,23,12,34,34,67,8});
		list.forEach(System.out::println);
		System.out.println("************************************");
		Set<Integer> set = new LinkedHashSet<>(list);
		set.forEach(System.out::println);
	}
	
}
