package com.fis.practice.collaction;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ReverseSorting {

	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(new Integer[]{12,23,12,34,34,67,8});
		list.forEach(System.out::println);
		System.out.println("************************************");
		Collections.sort(list, Collections.reverseOrder());
		list.forEach(System.out::println);
		System.out.println("************************************");
		Collections.sort(list);
		list.forEach(System.out::println);

	}

}
