package com.fis.practice.collaction;
public class TNStackClient {
 
    /**
     * @param args
     */
    public static void main(String[] args) {
        TNStack tns = new TNStack(3);
        // push some elements
        if(!tns.isFull())
            tns.push(4);
        if(!tns.isFull())
            tns.push(5);
        if(!tns.isFull())
            tns.push(3);
        if(!tns.isFull())
            tns.push(6);
        else
            System.out.println("Stack is full, cannot push element");
         
        // pop some elements
        if(!tns.isEmpty())
            tns.pop();
        if(!tns.isEmpty())
            tns.pop();
        if(!tns.isEmpty())
            tns.pop();
        if(!tns.isEmpty())
            tns.pop();
        else
            System.out.println("Stack is empty, cannot pop element");
         
        //reinsert to verify peek method
        if(!tns.isFull())
            tns.push(6);
         
        // peek couple of times; result should be same
        tns.peek();
        tns.peek();
    }
}