package com.fis.practice.sorting;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class MapShort {
	
	public static void main(String[] args) {
		Map<String, String> codenames = new HashMap<String, String>(); 
		codenames.put("a", "Sparkler"); 
		codenames.put("b", "Playground"); 
		codenames.put("d", "Kestrel"); 
		codenames.put("a", "Merlin"); 
		codenames.put("b", "Tiger"); 
		codenames.put("w", "Mustang"); 
		codenames.put("q", "Dolphin");
		codenames.forEach((k,v)-> System.out.println(k + "," + v));
		
		
		Map<String,String> sorteByKey = new TreeMap<String,String>(codenames);
		
		System.out.println("______________________________________________________________________________");
		sorteByKey.forEach((k,v)-> System.out.println(k + "," + v));		

	}

}
