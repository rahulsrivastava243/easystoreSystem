package com.fis.practice.concurrent;

public class RunTest implements Runnable{

	@Override
	public void run(){
		
		
	}

}
