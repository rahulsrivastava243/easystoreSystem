package com.fis.practice.concurrent;

public class TestOverridingImpl implements TestOverriding{

	@Override
	public void test() throws RuntimeException{
		// TODO Auto-generated method stub
		
	}

}
