package com.fis.practice.concurrent;

import java.util.concurrent.Callable;

public class TaskPrint implements Callable<String> { private String command;

public TaskPrint(String s){
    this.command=s;
}


private void processCommand() {
    try {
        Thread.sleep(1000);
    } catch (InterruptedException e) {
        e.printStackTrace();
    }
}

@Override
public String toString(){
    return this.command;
}

@Override
public String call() throws Exception {
    System.out.println(Thread.currentThread().getName()+" Start. Command = "+command);
    processCommand();
    System.out.println(Thread.currentThread().getName()+" End.");
    return "done";
    
}} 