package com.fis.practice.concurrent;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ExecutorServiceExample {
	public  static int count = 0;
     public static void main(String args[]) throws InterruptedException, ExecutionException {
    	
    	 ExecutorService executor = Executors.newFixedThreadPool(3);
         for (int i = 0; i < 10; i++) {
             Callable<String> worker = new TaskPrint("" + i);
             Future<String> future = executor.submit(worker);
             System.out.println(future.get());
             System.out.println("##################");
             
           }
         executor.shutdown();
         while (!executor.isTerminated()) {
         }
         System.out.println("Finished all threads");
    	 
     }
    }