package com.fis.practice.concurrent;

public interface TestOverriding {

	void test()throws Exception;
}
