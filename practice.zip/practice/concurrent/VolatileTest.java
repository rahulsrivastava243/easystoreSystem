package com.fis.practice.concurrent;

public class VolatileTest {
	private  volatile Integer abc = 0;
	private  Integer xyz = 0;
	public static void main(String[] args) {
		
		new VolatileTest().startThread();
	}
	
	
	private void startThread(){

		Thread t1 = new Thread(()-> {
			abc++;
			xyz++;
			System.out.println(abc);
			System.out.println(xyz);
		});
		
		Thread t2 = new Thread(()-> {
			abc++;
			xyz++;
			System.out.println(abc);
			System.out.println(xyz);
		});
		
		t1.start();
		t2.start();
		System.out.println(abc);
		System.out.println(xyz);
		
	
	}

}
