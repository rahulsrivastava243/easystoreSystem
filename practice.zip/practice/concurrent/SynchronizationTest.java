package com.fis.practice.concurrent;

public class SynchronizationTest {
	
	public synchronized void test(){
		
	}
	
   public synchronized static void testStatic(){
		
	}
   
   public synchronized void test1(){
	   
   }
   
   public  void name(){
	   
   }

}
