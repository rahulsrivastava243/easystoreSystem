package com.fis.practice.bitwiseoperator;

public class AndTest {
	
	int[] a = {1,2,1,2,3,5,5,7,3};
	
	public int findUniqueNumber(){
		int result = 0;
		for(int i = 0 ;i< a.length ; i++){
			result = result|a[i];
		}
		return result;
	}

	public static void main(String[] args) {
		
           System.out.println(new AndTest().findUniqueNumber());
	}

	

}
