package com.fis.geeksforgeeks;

public class SwapTwoStringWithoutUsingThirdVariable {

	public static void main(String[] args) {
		method1();
	}
	
	public static void method1(){
		String s1= "hello";
		String s2 = "world";
		System.out.println(" s1: " + s1 + "  s2: "+s2);
		s1 = s1 + s2;
		s2 = s1.substring(0,s2.length());
		s1 = s1.substring(s2.length(),s1.length());
		System.out.println(" s1: " + s1 + " s2: "+s2);
	}
}
