package com.fis.geeksforgeeks;

public class LongestSequence {

	public static void main(String[] args) {
		String s = "raahuhlh";
		System.out.println(maxRepeted(s));
		//System.out.println(maxRepeating_(s));
		

	}
	
	static char maxRepeating_(String str)
	{
	    int n = str.length();
	    int count = 0;
	    char res = str.charAt(0);
	    int cur_count = 1;
	 
	    // Traverse string except last character
	    for (int i=0; i<n; i++)
	    {
	        // If current character matches with next
	        if (i <= n-1 && str.charAt(i) == str.charAt(i+1))
	            cur_count++;
	 
	        // If doesn't match, update result
	        // (if required) and reset count
	        else
	        {
	            if (cur_count > count)
	            {
	                count = cur_count;
	                res = str.charAt(i);
	            }
	            cur_count = 1;
	        }
	    }
	 
	    return res;
	}
	
	static char maxRepeted(String s){
		if(s.length()<=0){
			return 0;
		}
		int len = s.length();
		int count = 0;
		char result= s.charAt(0);
		for(int i =0 ;i < len ; i++){
			int cur_count = 1;
			for(int j = i +1 ; j < len ;j++){
				if(s.charAt(i) != s.charAt(j)){
					break;
				}
				else{
					cur_count++;
				}
			}
			
			if(count <= cur_count){
				count = cur_count;
				result = s.charAt(i);
			}
		}
		
		return result;
	}
	
	 static char maxRepeating(String str)
	    {
	        int len = str.length();
	        int count = 0;
	 
	        // Find the maximum repeating character
	        // starting from str[i]
	        char res = str.charAt(0);
	        for (int i=0; i<len; i++)
	        {
	            int cur_count = 1;
	            for (int j=i+1; j<len; j++)
	            {
	                if (str.charAt(i) != str.charAt(j))
	                    break;
	                cur_count++;
	            }
	 
	            // Update result if required
	            if (cur_count > count)
	            {
	                count = cur_count;
	                res = str.charAt(i);
	            }
	        }
	        return res;
	    }
	 

}
