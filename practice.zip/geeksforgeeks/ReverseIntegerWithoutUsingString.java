package com.fis.geeksforgeeks;

public class ReverseIntegerWithoutUsingString {

	public static void main(String[] args) {
		int value = 123456789;
		int rev = 0;
		while(value > 0){
			rev = value%10 + rev*10; 
			value = value/10;
		}
		System.out.println(rev);

	}

}
