package com.fis.geeksforgeeks;

public class ReverseStringWithoutUsingTemp {

	public static void main(String[] args) {
		method2();
	}
	
	public static void method1(){
		String reverseMe = "rahul srivastava";
		for (int i = 0; i < reverseMe.length(); i++) {
		    reverseMe = reverseMe.substring(1, reverseMe.length() - i)
		        + reverseMe.substring(0, 1)
		        + reverseMe.substring(reverseMe.length() - i, reverseMe.length());
		 }
		 System.out.println(reverseMe);
	}
	
	public static void method2(){
		String s = "rahul srivastava";
		for(int i = 0; i < s.length(); i++)
		{
		    s = s.substring(1, s.length() - i) + s.charAt(0) + s.substring(s.length() - i);
		}
		System.out.println(s); // !dlroW olleH
	}
	
	
	public static void method3(){
		String s = "rahul srivastava";
		int r[] = new int[s.length()];

		int idx = r.length - 1;

		for (int i : s.toCharArray()) {
		    r[idx--] = i;
		}

		s = s.substring(0, 0);

		for (int i : r) {
		    s = s.concat(String.valueOf((char)i));
		}
		
		System.out.println(s);
	}

}
