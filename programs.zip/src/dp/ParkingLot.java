package dp;

import java.util.Comparator;
import java.util.PriorityQueue;

public class ParkingLot {
	private static final int maxfloor=4;
	private static final int maxnumslots=10;
	
	private PriorityQueue<ParkingSpace> pq=new PriorityQueue<ParkingSpace>(maxfloor*maxnumslots,new Comparator<ParkingSpace>(		
			) {
				@Override
				public int compare(ParkingSpace o1, ParkingSpace o2) {
					if(o1.getFloor()==o2.getFloor()) {
						return o1.getSlot()-o2.getSlot();
					}else {
						return o1.getFloor()-o2.getFloor();
					}
					
				}
	});
	
	public ParkingSpace getNextAvailableParking() {
		if(pq.size()>0) {
			return pq.peek();
		}
		return null;
	}
	
	public void addParkingSpace(int floor,int slot) {
		ParkingSpace ps=new ParkingSpace(floor, slot);
		pq.add(ps);
	}
	
	public ParkingSpace park() {
		ParkingSpace ps=getNextAvailableParking();
		if(ps==null) {
			throw new IllegalStateException("Parking is full");
		}
		pq.remove(ps);
		return ps;
	}
	
	public void unpark(int floor,int slot) {
		ParkingSpace ps=new ParkingSpace(floor, slot);
		if(!pq.contains(ps)) {
			pq.add(ps);
		}
		else {
			throw new IllegalStateException("Invalid Parking Lot.");
		}
	}
	
	
	public static void main(String[] args) {
ParkingLot pl = new ParkingLot();
		
		pl.addParkingSpace(1, 1);
		pl.addParkingSpace(2, 1);
		pl.addParkingSpace(3, 1);
		pl.addParkingSpace(1, 2);
		pl.addParkingSpace(2, 2);
		pl.addParkingSpace(3, 2);
		
		ParkingSpace n = pl.getNextAvailableParking();
		System.out.println("Parked at Floor: " + n.getFloor() + ", Slot: " + n.getSlot());
		pl.park();
		//pl.unpark(2, n.getSlot());
		ParkingSpace n1=pl.getNextAvailableParking();
		System.out.println("Parked at floor:- "+n1.getFloor()+" , Slot:- "+n1.getSlot());
		pl.park();
		ParkingSpace n2=pl.getNextAvailableParking();
		System.out.println("Parked at floor:- "+n2.getFloor()+" , Slot:- "+n2.getSlot());
	}
	
	
	
   class ParkingSpace{
	   private int floor;
	   private int slot;
	   
	   
	   public ParkingSpace(int floor,int slot) {
		   if(floor>maxfloor || slot> maxnumslots) {
			   throw  new IllegalArgumentException("Invalid number format exception");
		   }
		   this.floor=floor;
		   this.slot=slot;
	   }


	public int getFloor() {
		return floor;
	}


	public void setFloor(int floor) {
		this.floor = floor;
	}


	public int getSlot() {
		return slot;
	}


	public void setSlot(int slot) {
		this.slot = slot;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + getOuterType().hashCode();
		result = prime * result + floor;
		result = prime * result + slot;
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ParkingSpace other = (ParkingSpace) obj;
		if (!getOuterType().equals(other.getOuterType()))
			return false;
		if (floor != other.floor)
			return false;
		if (slot != other.slot)
			return false;
		return true;
	}


	private ParkingLot getOuterType() {
		return ParkingLot.this;
	}
	
	
   }
}
