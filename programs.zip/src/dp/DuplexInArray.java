package dp;


import java.util.HashSet;
public class DuplexInArray {
	
	final String l=null;
    public	DuplexInArray() {
    	//DuplexInArray();
    }
	public static void main(String[] args) throws InterruptedException {
		int [] arr= {1,2,3,-5,-8,7,-2,-3,5,-7,8,9,-9,4,5};
		long startTime = System.nanoTime();
		printPairs(arr);
		long endTime = System.nanoTime();
		long duration = (endTime - startTime); 
		System.out.println(duration);
		
		System.out.println("----------------");
		long startTime1 = System.nanoTime();
		printUsingPartition(arr);
		long endTime1 = System.nanoTime();
		long duration1 = (endTime1 - startTime1); 
		System.out.println(duration1);
		
	}
	
public static void printPairs(int [] a) throws InterruptedException {
	HashSet<Integer> hs=new HashSet<Integer>(a.length);
	
	for(int v:a) {
		int target=0-v;
		
		if(!hs.contains(target)) {
			hs.add(v);
		}else {
			System.out.println("("+v+","+target+")");
		}
	}
	
	
}

public static void printUsingPartition(int []a) {
	int j=partition(a, 0,a.length-1);
	for(int k:a) {
		System.out.print(k+" ");
	}
	System.out.println();
	for(int i=0;i<=j;i++) {
		for(int c=j+1;c<=a.length-1;c++) {
			if(a[i]+a[c]==0) {
				System.out.println("("+a[i]+","+a[c]+")");
			}
		}
	}
}

public static int partition(int [] a,int lo,int hi) {
	int v=0;
	int i=lo; int j=hi;
	
	while(true) {
		while(a[i]<v) {
			i++;
			if(i==hi)break;
		}
		
		while(v<a[j]) {
			j--;
			if(j==lo)break;
		}
		if(i>=j)break;
		
		exch(a,i,j);
	}
	return j;
}


public static void exch(int []a,int i,int j) {
	int temp=a[i];
	a[i]=a[j];
	a[j]=temp;
}

}
