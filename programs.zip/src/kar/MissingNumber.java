package kar;

public class MissingNumber {
	public static void main(String[] args) {
		//int [] a= {1,2,3,4,6,7,8,9};
		//System.out.println(missNum(a));
		int [] a= {1,1,2,2,1,3,3,1,7,6,7};
		int k=oddOccurenceElement(a);
		System.out.println(k);
	}
	
	
public static int missNum(int []a) {
	int i,x = 0,y=0;
	
	for(int j=0;j<a.length;j++) {
		x ^=a[j];
	}
	for(int k=1;k<= 9;k++) {
		y ^=k;
	}
	
	return x^y;
}

public static int oddOccurenceElement(int []a) {
	int res=0;
	for(int i=0;i<a.length;i++) {
		res=res^a[i];
	}
	return res;
}

}
