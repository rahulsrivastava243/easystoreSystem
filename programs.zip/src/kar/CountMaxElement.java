package kar;

import java.util.Arrays;

public class CountMaxElement {
	
	public static void main(String[] args) {
		int[] a= {2, 5, 3, 5, 4, 1, 7,5,5};
		//int k=countMaxInArray(a);
		//int k=countMaxElementBySorting(a);
		int k=maxRepeating(a, 9, 7);
		System.out.println("k:-"+k);
	}
	
	
public static int countMaxInArray(int [] a) {
     int max=0;
     int max_index=0;
	for(int i=0;i<a.length;i++){
		int counter=0;
		int j=0;
		for(j=0;j<a.length;j++) {
			 if(a[i]==a[j]) {
				 counter++;				
			 }
	    }
		if(counter>max) {
			max=counter;
			 max_index=i;
		}
	}
	System.out.println(a[max_index]);
	return max;
}

public static int countMaxElementBySorting(int [] a) {
	Arrays.sort(a);
	
	int max=0;
	int max_index=0;
	int counter=1;
	for(int i=0;i<a.length-1;i++) {
		
		if(a[i]==a[i+1]) {
			counter++;			
		}else {
			counter=1;
		}
		if(counter>max) {
			max=counter;
			max_index=i;
		}
	}
	System.out.println(a[max_index]);
	return max;
}

static int maxRepeating(int arr[], int n, int k)
{
    // Iterate though input array, for every element
    // arr[i], increment arr[arr[i]%k] by k
    for (int i = 0; i< n; i++)
        arr[(arr[i]%k)] += k;

    // Find index of the maximum repeating element
    int max = arr[0], result = 0;
    for (int i = 1; i < n; i++)
    {
        if (arr[i] > max)
        {
            max = arr[i];
            result = i;
        }
    }

    /* Uncomment this code to get the original array back
    for (int i = 0; i< n; i++)
      arr[i] = arr[i]%k; */
 System.out.println("Max repeating element:-"+arr[result]+" "+max);
    // Return index of the maximum element
    return result;
}

}
