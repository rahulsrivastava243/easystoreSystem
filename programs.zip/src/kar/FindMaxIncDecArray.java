package kar;

public class FindMaxIncDecArray {
public static void main(String[] args) {
  int [] a={-3, -2,60, 10, 9, 7, 6};
  int k=finmaxElement(a);
  System.out.println(k);
//int [] a= {1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
//int ans = findPos(a,0);
 // System.out.println(ans);
}
	
	
public static int finmaxElement(int [] a) {
	int first=0;
	int last=a.length-1;
	int mid;
	
	while(first<=last) {
		if(first==last) return a[first];
		else if(first==last-1)return Math.max(a[first],a[last]);
		else {
			mid=first+(last-first)/2;
			
			if(a[mid-1]<a[mid] && a[mid]>a[mid+1])
				return a[mid];
			else if(a[mid-1]<a[mid] && a[mid]<a[mid+1]) {
				  first=mid+1;
			}else if(a[mid-1]>a[mid]&&a[mid]>a[mid+1]) {
				last=mid-1;
			}else {
				return -1;
			}
				
		}
	
	}
	return -1;
}


public static int binarySearch(int [] a,int l,int h,int x) {
	int mid=l+(h-l)/2;
	if(h>=l) {
		if(a[mid]==x) {
			return mid;
		}else if(a[mid]>x) {
			return binarySearch(a, l, mid-x, x);
		}else {
				return binarySearch(a, mid+1, h, x);
		}
	}
	return -1;
}

public static int findPos(int [] arr,int x) {
	int l=0;int h=1;
	int val=arr[0];
	while(val>x) {
		l=h;
		h=2*h;
		val=arr[h];
	}
	
	return binarySearch(arr, l, h, x);
	
}
}
