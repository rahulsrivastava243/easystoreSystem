package kar;


import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class FindDup {
public static void main(String[] args) {
	 int [] arr={3, 2, 1, 2, 2, 3};
	 printDup(arr);
	 System.out.println("--------------");
	// sortAndPrintDup(arr);
	 System.out.println("----");
	// hashtableDup(arr);
	 System.out.println("-------");
	 firstDup(arr);
}	
	
	
public static void printDup(int [] a) {
	for(int i=0;i<a.length;i++) {
		for(int j=i+1;j<a.length;j++) {
			if(a[i]==a[j]) {
				System.out.println("Dup element:-"+a[i]);
				break;
			}
		}
	}
}

public static void sortAndPrintDup(int []a) {
	Arrays.sort(a);
	for(int i=0;i<a.length-1;i++) {
		if(a[i]==a[i+1]) {
			System.out.println("Dup element:-"+a[i]);
		}
	}
	
}

public static void hashtableDup(int []a) {
	HashMap<Integer,Integer> hs=new HashMap<>(a.length);
	for(int i=0;i<a.length;i++) {
		if(hs.containsKey(a[i])) {
			System.out.println("diplicate:-"+a[i]);
		}else {
		  hs.put(a[i], 1);
		}
	}
	
}

public static void firstDup(int []a) {
	HashMap<Integer,Integer> hs=new HashMap<>();
	int index=1;
	for(int i=0;i<a.length;i++) {
		
		if(hs.containsKey(a[i]) ) {
			if(hs.get(a[i])<0)continue;
			hs.put(a[i], -hs.get(a[i]));
		
		}else {
			hs.put(a[i], index);
			index++;
		}
	}
	System.out.println(hs);
	int min=-100;
	for(Map.Entry<Integer, Integer> m:hs.entrySet()) {
		int value=m.getValue();
		//System.out.println(value);
		if(value<0 && value>min)min=value;
		//System.out.println(min);
	}
	System.out.println(min);
	System.out.println(a[Math.abs(min+1)]);
}

}
