package kar;

import java.util.Arrays;

public class MinSum {
	public static void main(String[] args) {
		int [] a= {	1,60,-10,70,-80,85};
		//minSum(a);
		minSumBySort(a);
	}
	
public static void minSum(int [] a) {
	int i,j,min_i,min_j,min_sum,sum;
	if(a.length<2) {
		return;
	}
	
	min_i=0;
	min_j=1;
	min_sum=a[0]+a[1];
	
	for(i=0;i<a.length;i++) {
		for(j=i+1;j<a.length;j++) {
			sum=a[i]+a[j];
			if(Math.abs(min_sum)>Math.abs(sum)) {
				min_i=i;
				min_j=j;
				min_sum=sum;
			}
		}
	}
	System.out.println("min sum of array:-"+a[min_i]+" "+a[min_j]);
}

public static void minSumBySort(int [] a) {
	if(a.length<2)return;
	
	int l=0;int r=a.length-1;int sum=0;
	int min_l=l; int min_r=a.length-1;
	Arrays.sort(a);
	
	int min_sum=a[0]+a[1];
	while(l<r){
		 sum=a[l]+a[r];
		if(Math.abs(sum)<Math.abs(min_sum)) {
			min_l=l;
			min_r=r;
			min_sum=sum;
		}
		if(sum<0) {
			l++;
		}else {
			r--;
		}
		
	}	
	
	System.out.println("sum min elements:-"+a[min_l]+" "+a[min_r]);
}

}
