package mypack;

import java.util.Arrays;


public class RemoveDuplicate {
	public static void main(String[] args) {
		int [] arr= {5,5,5,6,5,2,1,3,4,2};
		Arrays.sort(arr);
		for(int h:arr) {
			System.out.print(h+" ");
		}
		int i=1;
		int j=0;
		
		while(i<arr.length) {
			if(arr[i]==arr[j]) {
				i++;
			}else {
				arr[++j]=arr[i++];
			}
		}
		
		int [] p=Arrays.copyOf(arr,j+1);
		System.out.println();
		for(int l:p) {
			System.out.print(l+" ");
		}
		
		
	}

}
