package mypack;

public class EvenOddDemo {
	public static void main(String[] args) {
		EvenOddPrinter eop=new EvenOddPrinter();
		
	    Thread t=new Thread(new Runnable() {

			@Override
			public void run() {
				for(int i=2;i<=100;i=i+2) {
					try {
						eop.printEven(i);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
			}
	    	
	    });	
	    
	    Thread t1=new Thread(new Runnable() {

			@Override
			public void run() {
				for(int i=1;i<=100;i=i+2) {
					try {
						eop.printOdd(i);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}	
				
			}
	    	
	    });	
	    t.start();
	    t1.start();
	}
}




class EvenOddPrinter{
  private boolean evenflag=false;  
  
  public void printEven(int num) throws InterruptedException {
	  synchronized (this) {
		while(!evenflag) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println(num);
		Thread.sleep(1000);
		evenflag=false;
		notify();
	}
  }
  
  public void printOdd(int num) throws InterruptedException {
	  synchronized (this) {
		while(evenflag) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	
		}
		
		System.out.println(num);
		Thread.sleep(1000);
		evenflag=true;
		notify();
	}
  }

}
