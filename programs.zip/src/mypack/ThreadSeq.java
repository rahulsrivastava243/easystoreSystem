package mypack;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class ThreadSeq {
   public static void main(String[] args) {

	Worker w1=new Worker();
	Worker w2=new Worker();
	Worker w3=new Worker();
	
	w1.setNext(w2);
	w2.setNext(w3);
	w3.setNext(w1);
	
	Thread t1=new Thread(w1);
	Thread t2=new Thread(w2);
	Thread t3=new Thread(w3);
	
	t1.start();
	t2.start();
	t3.start();
	
	w1.accept(1);
	
}   
}

class Worker implements Runnable{
	BlockingQueue<Integer> bq=new LinkedBlockingQueue<Integer>();
	Worker next=null;
	
	
	
	public void setNext(Worker t) {
		this.next=t;
	}
	
	public void accept(int i) {
		bq.add(i);
	}

	@Override
	public void run() {
		while(true) {
			try {
				int q=bq.take();
				System.out.println(Thread.currentThread().getName()+" "+q);;
				Thread.sleep(1000);
				if(next!=null) {
					next.accept(q+1);
					//bq.add(q+1);
				}
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
}
