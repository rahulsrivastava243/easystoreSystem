package mypack;

import java.util.ArrayList;
import java.util.List;



public class ThreadSeq1 {

	 public static void main(String[] args) {
			final  Object obj1=new Object();
			final  Object obj2=new Object();
			final  Object obj3=new Object();
			
	Worker1 w1=new Worker1(obj1,obj2);
	Worker1 w2=new Worker1(obj2,obj3);
	Worker1 w3=new Worker1(obj3,obj1);
	     w1.setNext(w2);
	     w2.setNext(w3);
	     w3.setNext(w1);
	     
	     Thread t1=new Thread(w1);
	     t1.setName("one");
	     Thread t2=new Thread(w2);
	     t2.setName("two");
	     Thread t3=new Thread(w3);
	     t3.setName("Three");
	     t1.start();t2.start();t3.start();
	     
	     w1.addtoList(1);
	 }
}




class Worker1 extends Thread{
	List<Integer> list=new ArrayList<Integer>();
	Worker1 next;
	Object obj1;
	Object obj2;
	//Object obj3;
	
	Worker1(Object obj1,Object obj2){
		this.obj1=obj1;
		this.obj2=obj2;
		//this.obj3=obj3;
	}
	

	
	public void setNext(Worker1 t) {
		this.next=t;
	}
	
	public  void addtoList(int i) {
		
		list.add(i);
	    
		}
	
	
	
	public void run() {

	while(true) {			
		synchronized (obj1) {
			if(list.size()==0) {
				try {
					obj1.wait();
					
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}	}
		
		int p=list.get(0);
		list.remove(0);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println(Thread.currentThread().getName()+" "+p);
		System.out.println();
		if(next!=null) {
           
			synchronized (obj2) {
				next.addtoList(++p);
				obj2.notify();
			}
			
			
	
		}
	}
	}
	}
	

