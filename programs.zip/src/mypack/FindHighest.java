package mypack;

public class FindHighest {
	public static void main(String[] args) {
		int [] arr= {5,2,1,6,5,2,1,3,4,2};
		int findhighest=0;
		int sechighest=0;
		
		for(int i=0;i<arr.length;i++) {
			if(findhighest<arr[i]) {
				sechighest=findhighest;
				findhighest=arr[i];
			}else if(sechighest<arr[i]){
				sechighest=arr[i];
			}
		}
		System.out.println(findhighest+" "+sechighest);
	}

}
