package mypack;



public class Test {
	static {
		System.out.println();
	}
	public static void main(String [] args) {
		
	}
	
	public static void save() {
		System.out.println("without const");
	}
	
	public static void save(int a) {
		System.out.println("with cons");
	}
	static int i=9;
	

}
class Employee implements Comparable<Employee>{
	private String name;

	Employee(String name){
		this.name=name;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public int compareTo(Employee o) {
		// TODO Auto-generated method stub
		return name.compareTo(o.name);
	}
	
}

class Depart implements Comparable<Depart>{
	String name;
    
	Depart(String name){
		this.name=name;
	}
	@Override
	public int compareTo(Depart o) {
		// TODO Auto-generated method stub
		return name.compareTo(o.name);
	}
}
