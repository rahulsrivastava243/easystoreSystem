package mypack;

import java.util.concurrent.atomic.AtomicInteger;

public class ThreadSeq2 {
public static void main(String[] args) {
	AtomicInteger it=new AtomicInteger(0);
	Object obj=new Object();
	Workerseq ws1=new Workerseq(obj,0,it);
	Workerseq ws2=new Workerseq(obj,1,it);
	Workerseq ws3=new Workerseq(obj,2,it);
	Workerseq ws4=new Workerseq(obj,3,it);
	
	new Thread(ws1).start();
	new Thread(ws2).start();
	new Thread(ws3).start();
	new Thread(ws4).start();
	
}
}


class Workerseq implements Runnable{
	Object obj;
	int id;
	AtomicInteger ati;
	
	public Workerseq(Object obj,int id,AtomicInteger ati) {
		this.obj=obj;
		this.id=id;
		this.ati=ati;
	}

	@Override
	public void run() {
		synchronized (obj) {
			try {
			while(ati.intValue()<100) {
				if(ati.intValue()%4==this.id) {
					System.out.println(Thread.currentThread().getName()+" with thread id :-"+id+" prints:- "+ati);
					ati.getAndIncrement();
					obj.notifyAll();
				}else {
					
						obj.wait();
					
				}
				Thread.sleep(1000);
			}
		
		}catch(InterruptedException ex) {
			ex.printStackTrace();
		}
		
	}
	
}
}