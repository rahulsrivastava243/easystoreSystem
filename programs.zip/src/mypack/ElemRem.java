package mypack;

import java.util.Scanner;

public class ElemRem {
	static int [] arr= {5,2,1,6,5,2,1,3,4,2};
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("please enter num to remove:-");
		int num=sc.nextInt();
		
		for(int i=0;i<arr.length;i++) {
			if(num==arr[i]) {
				for(int j=i;j<arr.length-1;j++) {
					arr[j]=arr[j+1];
				}
				break;
			}
			
		}
		
		for(int k:arr) {
			System.out.print(k+" ");
		}
	}
	
	
}
