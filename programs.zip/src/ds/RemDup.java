package ds;

import java.util.Arrays;
import java.util.Collections;

public class RemDup {
  public static void main(String[] args) {
	  int arr[]= {5,6,2,6,4,1,3,5,2,5,1,9,3};
	  int arr1 []=remDup(arr);
	  for(int i:arr1) {
		  System.out.print(i+" ");
	  }
	  System.out.println();
	  System.out.println("------");
	  arr1=remDup1(arr);
	  for(int i:arr1) {
		  System.out.print(i+" ");
	  }
}
  
  public static int [] remDup(int [] arr) {
	  int [] result=new int[arr.length];
	  Arrays.sort(arr);
	  int first=arr[0];
	  result[0]=first;
	  for(int i=1;i<arr.length;i++) {
		  if(first!=arr[i]) {
			  result[i]=arr[i];
		  }
		  first=arr[i];
	  }
	 return result; 
  }
  
  public static int [] remDup1(int [] arr) {
    Arrays.sort(arr);
    int i=1;
    int j=0;
    
    while(i<arr.length) {
    	if(arr[i]==arr[j]) {
    		i++;
    	}else {
    		arr[++j]=arr[i++];
    	}
    	
    }
    
    return Arrays.copyOf(arr,j+1);
	  
  }
}
