package ds;

public class Fabinocci {
	
	public static void main(String[] args) {
	printFab();
	}

	
  public static void printFab() {
	  int n1=0;int n2=0;	
	  int n3=1;
	  
	  for(int i=0;i<10;i++) {
		  System.out.println(n3);
		  n1=n2;
		  n2=n3;
		  n3=n1+n2;
	  }
  }
}
