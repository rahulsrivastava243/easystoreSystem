package ds;
public class PairSum {
  public static void main(String[] args) {
	int [] arr= {2, 4, 3, 5, 6, -2, 4, 7, 8, 9};
	pairSum(arr, 7);
}	
	public static void  pairSum(int []a,int num ) {
		for(int i=0;i<a.length;i++) {
			for(int j=i+1;j<a.length;j++) {
				if(a[i]+a[j]==7) {
					System.out.println("("+a[i]+","+a[j]+")");
				}
			}
		}
	}
	
	
	

}
