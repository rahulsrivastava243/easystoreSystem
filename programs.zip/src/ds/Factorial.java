package ds;

public class Factorial {
	public static void main(String[] args) {
		System.out.println(factItr(3));
		System.out.println("---");
		System.out.println(factRec(3));
	}
	
	
	
public static int factItr(int i) {
	int fact=1;
	while(i>0) {
		fact=fact*i;
		i--;
		
	}
	return fact;
}

public static int factRec(int i) {
	if(i==1)return 1;
	return i*factRec(i-1);
}

}
