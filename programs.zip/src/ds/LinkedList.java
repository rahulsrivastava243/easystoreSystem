package ds;

import java.util.Iterator;

public class LinkedList<Item> implements Iterable<Item>{
	public Node first;
	
	
	private class Node{
		public Item item;
		private Node next;
		
		public Node(Item item,Node next) {
			this.item=item;
			this.next=next;
		}
	}
	
public void addFirst(Item item) {
	Node old=first;
	first=new Node(item,old);
}


public void addLast(Item item) {
	Node f=first;
	while(f.next!=null) {
		f=f.next;
	}
	f.next=new Node(item,null);
	
}

public void addAfter(Item item,Item after) {
	Node head=first;
	while(head!=null && !after.equals(head.item)) {
		head=head.next;
	}
	if(head!=null)head.next=new Node(item,head.next);
}

public void addBefore(Item item,Item before) {
	Node head=first;
	if(head==null)return;
	if(before.equals(head.item)) {
		head=new Node(item,head.next);
	}
	Node prev=null;
	while(head!=null && !before.equals(head.item)) {
		prev=head;
		head=head.next;
	}
	if(head!=null) {
		prev.next=new Node(item,head);
	}
}

public Item getFirst() {
	if(first==null)return null;
	else return first.item;
}

public Item getLast() {
	Node f=first;
	if(f==null)return null;
	while(f.next!=null) {
		f=f.next;
	}
		return f.item;
}

public void reverse() {
	Node head=first;
	Node prev=null;
	while(head!=null) {
		Node next=head.next;
		head.next=prev;
		prev=head;
		head=next;
	}
	first=prev;
}

public void recursiveReverse(Node head,Node prev) {
	
	if(head.next==null) {
		first=head;
		first.next=prev;
		return;
	}
	
	Node head1=head.next;
	head.next=prev;
	recursiveReverse(head1, head);
	
	
}

public void middleElement() {
	Node fast=first;
	Node slow=first;
	if(first==null)return;
	while(fast!=null && fast.next!=null) {
		fast=fast.next.next;
		slow=slow.next;
	}
	System.out.println("Middle element :-" +slow.item);
}

public void printNdata(int n) {
	Node mainNode=first;
	Node refNode=first;
	int count=0;
	while(count<n) {
		if(refNode==null) {
			return;
		}
		refNode=refNode.next;
		count++;
	}
	
	while(refNode!=null) {
		refNode=refNode.next;
		mainNode=mainNode.next;
	}
	
	System.out.println(n+"th node from end:-"+mainNode.item);
}


@Override
public Iterator<Item> iterator() {
	// TODO Auto-generated method stub
	return new ListItr();
}

 class ListItr implements Iterator<Item>{
	 Node head=first;

	@Override
	public boolean hasNext() {
		// TODO Auto-generated method stub
		return head!=null;
	}

	@Override
	public Item next() {
		// TODO Auto-generated method stub
		Item item=head.item;
		head=head.next;
		return item;
	}
	 
	 
 }
 
 public static void main(String args []) {
	 LinkedList<String> ll=new LinkedList<>();
	 ll.addFirst("first");
	 ll.addFirst("second");
	 ll.addFirst("third");
	 ll.addLast("fourth");
	 ll.addLast("fifth");
	 
	 ll.addAfter("after fourth", "fourth");
	 ll.addAfter("after fifth", "fifth");

	 ll.addBefore("before Second","second");
	 ll.addBefore("before fifth","fifth");
	 
	 for(String str:ll) {
		 System.out.println(str+" ");
	 }
	 System.out.println();
	 ll.middleElement();
	 ll.printNdata(6);
	// ll.reverse();
	 ll.recursiveReverse(ll.first, null);
	 System.out.println("after reverse----");
	 for(String str:ll) {
		 System.out.println(str+" ");
	 }
 }
}
