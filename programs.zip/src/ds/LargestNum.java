package ds;

import java.util.Arrays;
import java.util.Comparator;



public class LargestNum {
  public static void main(String[] args) {
	Integer [] a= {2, 35, 23, 6, 8};
	findLargestNum(a);
}
  
  
 public static void findLargestNum(Integer [] a) {
	 Arrays.sort(a, new Comparator<Integer>() {

		@Override
		public int compare(Integer o1, Integer o2) {
			System.out.println("o1:-"+o1+" "+"o2:-"+o2);
			String a=o1.toString()+o2.toString();
			String b=o2.toString()+o1.toString();
			
			System.out.println("String a:-"+a);
			System.out.println("String b:-"+b);
			
			return b.compareTo(a);
		}
	});
	 
	for(Integer i:a) {
		System.out.print(i);
	}
 }
}
