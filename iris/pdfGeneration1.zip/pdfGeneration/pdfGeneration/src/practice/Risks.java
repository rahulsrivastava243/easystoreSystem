package practice;

import java.util.ArrayList;
import java.util.List;
import com.itextpdf.kernel.colors.DeviceCmyk;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;

public class Risks {
	public void Run(Document doc) throws Exception {
		new RiskPdf().createpdf(doc);
		new Risks().manipulatePdf(doc);
	}

	protected void manipulatePdf(Document doc) throws Exception {
		Table table = new Table(8);
		RiskBean[] obj=getData();
		for(int count=0;count<obj.length;count++){
				if (count % 2 == 0){
					table.addCell(new Cell().add(new Paragraph(obj[count].getCategory())).setFontSize(10).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.3).setWidth(85));
					table.addCell(new Cell().add(new Paragraph(obj[count].getTrack())).setFontSize(10).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.3).setWidth(85));
					table.addCell(new Cell().add(new Paragraph(obj[count].getDescription())).setFontSize(10).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.3).setWidth(85));
					table.addCell(new Cell().add(new Paragraph(obj[count].getOwner())).setFontSize(10).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.3).setWidth(85));
					table.addCell(new Cell().add(new Paragraph(obj[count].getActionPlan())).setFontSize(10).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.3).setWidth(85));
					table.addCell(new Cell().add(new Paragraph(obj[count].getIdentification())).setFontSize(10).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.3).setWidth(85));
					table.addCell(new Cell().add(new Paragraph(obj[count].getTarget())).setFontSize(10).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.3).setWidth(85));
					table.addCell(new Cell().add(new Paragraph(obj[count].getStatus())).setFontSize(10).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.3).setWidth(85));
				}
				else
				{ table.addCell(new Cell().add(new Paragraph(obj[count].getCategory())).setFontSize(10).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.1).setWidth(85));
				table.addCell(new Cell().add(new Paragraph(obj[count].getTrack())).setFontSize(10).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.1).setWidth(85));
				table.addCell(new Cell().add(new Paragraph(obj[count].getDescription())).setFontSize(10).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.1).setWidth(85));
				table.addCell(new Cell().add(new Paragraph(obj[count].getOwner())).setFontSize(10).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.1).setWidth(85));
				table.addCell(new Cell().add(new Paragraph(obj[count].getActionPlan())).setFontSize(10).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.1).setWidth(85));
				table.addCell(new Cell().add(new Paragraph(obj[count].getIdentification())).setFontSize(10).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.1).setWidth(85));
				table.addCell(new Cell().add(new Paragraph(obj[count].getTarget())).setFontSize(10).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.1).setWidth(85));
				table.addCell(new Cell().add(new Paragraph(obj[count].getStatus())).setFontSize(10).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.1).setWidth(85));
			}
		}
		doc.add(table);
	}
	public RiskBean[] getData() {
		RiskBean[] obj=new RiskBean[2];
		obj[0]=new RiskBean();
		obj[0].setCategory("Risk");
		obj[0].setTrack("Citi");
		obj[0].setDescription("Unable to fulfill new positions due to thin pipeline leading to revenue loss and customer dis-satisfaction");
		obj[0].setOwner("Deepak/Neeraj");
		obj[0].setActionPlan("Forming a separate team to conduct interviews full time. Project Manager on-boarded,Conducting at-least 8 interviews on week days,Plan for outstation recruitment drives,Open to external vendors");
		obj[0].setIdentification("09/25/2019");
		obj[0].setTarget("");
		obj[0].setStatus("Open. Recruitment of the panel in-progress");
		obj[1]=new RiskBean();
		obj[1].setCategory("Issue");
		obj[1].setTrack("Resignations and Performance");
		obj[1].setDescription("Resignations - Rajeev, Saurabh, Rajat, Aditya, Kavita Performance - Ankit & Syed Arif ,Swarna Raj, Nitish Bhardwaj , Shweta, & Sandeep");
		obj[1].setOwner("Neeraj");
		obj[1].setActionPlan("Build healthy pipeline,Limited pool of resources and tremendous pressure to fill  new positions or backfill");
		obj[1].setIdentification("28/08/2017");
		obj[1].setTarget("");
		obj[1].setStatus("Open");	
		return obj;
	}
}
