package practice;

import java.util.ArrayList;
import java.util.List;
import com.itextpdf.kernel.colors.DeviceCmyk;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;

public class Sales {
	public void Run(Document doc) throws Exception {
		new SalePdf().createpdf(doc);
		new Sales().manipulatePdf(doc);
	}

	protected void manipulatePdf(Document doc) throws Exception {
		Table table = new Table(8);
		SaleBean[] obj=getData();
		for(int count=0;count<obj.length;count++){
			if (count % 2 == 0) {
			 table.addCell(new Cell().add(new Paragraph(obj[count].getS_no())).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.3).setWidth(58).setFontSize(10));
			 table.addCell(new Cell().add(new Paragraph(obj[count].getTrack())).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.3).setWidth(85).setFontSize(10));
			 table.addCell(new Cell().add(new Paragraph(obj[count].getDescription())).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.3).setWidth(85).setFontSize(10));
			 table.addCell(new Cell().add(new Paragraph(obj[count].getOwner())).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.3).setWidth(85).setFontSize(10));
			 table.addCell(new Cell().add(new Paragraph(obj[count].getHelp())).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.3).setWidth(85).setFontSize(10));
			 table.addCell(new Cell().add(new Paragraph(obj[count].getIdentification())).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.3).setWidth(85).setFontSize(10));
			 table.addCell(new Cell().add(new Paragraph(obj[count].getTarget())).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.3).setWidth(85).setFontSize(10));
			 table.addCell(new Cell().add(new Paragraph(obj[count].getStatus())).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.3).setWidth(85).setFontSize(10));
			}
			else{
				 table.addCell(new Cell().add(new Paragraph(obj[count].getS_no())).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.1).setWidth(58).setFontSize(10));
				table.addCell(new Cell().add(new Paragraph(obj[count].getTrack())).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.1).setWidth(85).setFontSize(10));
				 table.addCell(new Cell().add(new Paragraph(obj[count].getDescription())).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.1).setWidth(85).setFontSize(10));
				 table.addCell(new Cell().add(new Paragraph(obj[count].getOwner())).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.1).setWidth(85).setFontSize(10));
				 table.addCell(new Cell().add(new Paragraph(obj[count].getHelp())).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.1).setWidth(85).setFontSize(10));
				 table.addCell(new Cell().add(new Paragraph(obj[count].getIdentification())).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.1).setWidth(85).setFontSize(10));
				 table.addCell(new Cell().add(new Paragraph(obj[count].getTarget())).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.1).setWidth(85).setFontSize(10));
				 table.addCell(new Cell().add(new Paragraph(obj[count].getStatus())).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.1).setWidth(85).setFontSize(10));
			}
		}
		doc.add(table);
	}
	public SaleBean[] getData() {
		SaleBean[] obj=new SaleBean[2];
		obj[0]=new SaleBean();
		obj[0].setS_no("1");
		obj[0].setTrack("All");	
		obj[0].setDescription("Need to backfill critical positions � resignation and performance");
		obj[0].setOwner("Deepak/Neeraj");
		obj[0].setHelp("Before filling any new positions, need to concentrate on strengthening the existing team by backfilling resignation, eCore and nonperformance cases,Resignation � 5 (1 Lead & 4 developers),eCore Replacement � 2 (1 Lead & 1 developer),Performance 6 (Need to replace 3-4 developers immediately)");
		obj[0].setIdentification("08/28/17");
		obj[0].setTarget("");
		obj[0].setStatus("Open");
		obj[1]=new SaleBean();
		obj[1].setS_no("2");
		obj[1].setTrack("All");	
		obj[1].setDescription("Communication to Citi managers for change in token");
		obj[1].setOwner("Jatin/Dave/Beth/Mani");
		obj[1].setHelp("11/03: Request raised for replacing 2 tokens today.Inform all Citi Managers who are working directly with the offshore team");
		obj[1].setIdentification("10/11/17");
		obj[1].setTarget("");
		obj[1].setStatus("WIP");
		return obj;
	}
}
