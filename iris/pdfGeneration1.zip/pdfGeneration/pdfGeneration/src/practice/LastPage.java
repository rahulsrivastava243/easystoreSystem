package practice;

import com.itextpdf.io.font.FontConstants;
import com.itextpdf.kernel.colors.DeviceRgb;
import com.itextpdf.kernel.colors.WebColors;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;

public class LastPage {
	public void Run(Document doc) throws Exception {
		DeviceRgb myColor = WebColors.getRGBColor("000080");
		PdfFont bold = PdfFontFactory.createFont(FontConstants.TIMES_BOLD);
		doc.add(new Paragraph("Thank You").setFont(bold).setFontSize(35).setFixedPosition(335, 300, 500)
				.setFontColor(myColor));
	}
}
