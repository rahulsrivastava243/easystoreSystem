package practice;

import java.util.ArrayList;
import java.util.List;
import com.itextpdf.kernel.colors.DeviceCmyk;
import com.itextpdf.kernel.colors.DeviceRgb;
import com.itextpdf.kernel.colors.WebColors;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;

public class Milestones {

	public void Run(Document doc) throws Exception {
		new MilestonesPdf().createpdf(doc);
		new Milestones().manipulatePdf(doc);
	}

	protected void manipulatePdf(Document doc) throws Exception {
		int count = 0;
		Table table = new Table(9);
		List<List<String>> dataset = getData();
		for (List<String> record : dataset) {
			count++;
			int num = 0;
			for (String field : record) {
				if (count % 2 == 0) {
					if (num == 8) {
						DeviceRgb myColor = WebColors.getRGBColor("#008000");
						Cell cell = new Cell().add(new Paragraph("").setWidth(25).setFontSize(10));
						cell.setBackgroundColor(myColor);
						table.addCell(cell);
					} else if (num == 1)
						table.addCell(new Cell().add(new Paragraph(field))
								.setBackgroundColor(DeviceCmyk.CYAN, (float) 0.3).setFontSize(10).setWidth(95));
					else if (num == 7)
						table.addCell(new Cell().add(new Paragraph(field))
								.setBackgroundColor(DeviceCmyk.CYAN, (float) 0.3).setFontSize(10).setWidth(55));
					else
						table.addCell(new Cell().add(new Paragraph(field))
								.setBackgroundColor(DeviceCmyk.CYAN, (float) 0.3).setFontSize(10).setWidth(85));
					num++;
				} else {
					if (num == 8)
						table.addCell(new Cell().add(new Paragraph("")).setBackgroundColor(DeviceCmyk.YELLOW)
								.setFontSize(10).setWidth(25));
					else if (num == 1)
						table.addCell(new Cell().add(new Paragraph(field))
								.setBackgroundColor(DeviceCmyk.CYAN, (float) 0.1).setWidth(95).setFontSize(10));
					else if (num == 7)
						table.addCell(new Cell().add(new Paragraph(field))
								.setBackgroundColor(DeviceCmyk.CYAN, (float) 0.1).setWidth(55).setFontSize(10));
					else
						table.addCell(new Cell().add(new Paragraph(field))
								.setBackgroundColor(DeviceCmyk.CYAN, (float) 0.1).setWidth(85).setFontSize(10));
					num++;
				}
			}
		}
		doc.add(table);
	}

	public List<List<String>> getData() {
		List<List<String>> data = new ArrayList<>();
		/*
		 * String[] tableTitleList = { "", "Track", " Description", " Owner",
		 * "Help Needed", "Identification Date", " Target Date", "Status" };
		 * data.add(Arrays.asList(tableTitleList)); for (int i = 0; i < 10;) {
		 * List<String> dataLine = new ArrayList<>(); i++; for (int j = 0; j <
		 * tableTitleList.length; j++) { dataLine.add(tableTitleList[j] + " " +
		 * i); } data.add(dataLine); }
		 */
		List<String> dataLine = new ArrayList<>();
		dataLine.add("CGS");
		dataLine.add("Requirement Design and Estimate for BAU 1 WI�s");
		dataLine.add("3-Oct-2017");
		dataLine.add("13-Oct-2017");
		dataLine.add("3-Oct-2017");
		dataLine.add("");
		dataLine.add(
				"WI#81904 pending with BA, Requirements in progress.WI#94056 - Satish provided walkthrough last week.");
		dataLine.add("");
		dataLine.add("");
		data.add(dataLine);
		List<String> dataLine1 = new ArrayList<>();
		dataLine1.add("CDM");
		dataLine1.add("Feature development for CCB Group");
		dataLine1.add("17-Aug-2017");
		dataLine1.add("15-Nov-17");
		dataLine1.add("17-Aug-2017");
		dataLine1.add("");
		dataLine1.add(
				"Delay in design agreement with Citi CCB team due to which there is a schedule impact of 4 weeks.  Also customer has raised concern on design discussion progress and inability of IRIS team to provide tech lead  open position for more than 2 months.");
		dataLine1.add("");
		dataLine1.add("");
		data.add(dataLine1);
		return data;
	}
}
