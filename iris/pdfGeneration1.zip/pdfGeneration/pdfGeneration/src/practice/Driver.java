package practice;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;

import org.apache.poi.xwpf.usermodel.IBodyElement;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFPictureData;
import org.apache.poi.xwpf.usermodel.XWPFTable;

import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.AreaBreak;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.property.AreaBreakType;

public class Driver {

	public static final String DEST = "C:\\Users\\raghavender.singh\\Desktop\\report12.pdf";
	public static final String INPT_SRC = "LIC proofs submision form 2018.docx";
	static LinkedHashMap<Object,Object> wordDocDataMap = new LinkedHashMap<>();
	PdfWriter pdfWriter ;
	PdfDocument pdfDoc;
	Document doc;
	
	void prePareInputData() throws Exception {
		
		System.out.println("Entring inside method  prePareInputData ");
		 File file = new File(INPT_SRC);
         FileInputStream fis;
         XWPFDocument inDocument;
		try {
			fis = new FileInputStream(file.getAbsolutePath());
			inDocument = new XWPFDocument(fis);
			List<IBodyElement> bodyElementList = inDocument.getBodyElements();
			int count=1;
			for(IBodyElement bodyEle : bodyElementList) {
				String bodyEleName = bodyEle.getElementType().name();
				wordDocDataMap.put(bodyEleName+count, bodyEle);
				count++;
			}
			
			List<XWPFPictureData> picList = inDocument.getAllPictures();
			for(XWPFPictureData data : picList) {
				wordDocDataMap.put(data.getFileName()+count, data);
				count++;
			}
				
				
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			throw new FileNotFoundException();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
         
		System.out.println("method prePareInputData completed ");
	}
	
	void AddImageinPdf(){
		
	}
	
	public static void main(String[] args) throws Exception {
		
		
		Driver driver = new Driver();
		driver.prePareInputData();
		
		
		File file = new File(DEST);
		file.getParentFile().mkdirs();
		driver.pdfWriter = new PdfWriter(DEST);
		
		driver.pdfDoc= new PdfDocument(driver.pdfWriter);
		driver.doc = new Document(driver.pdfDoc, PageSize.A4.rotate());
		
		
		/*String img = "./images/iris logo.png";
		Image image = new Image(ImageDataFactory.create(img));
		image.setHeight(50);
		image.setWidth(55);
		image.setFixedPosition(740, 550);
		driver.doc.add(image);*/
		
		
		
		//new FrontPage().Run(driver.doc);
		
		
		//driver.doc.add(new AreaBreak(AreaBreakType.NEXT_PAGE));
	for(Entry<Object,Object> entry: wordDocDataMap.entrySet()) {
		if(entry.getValue() instanceof IBodyElement) {
			
			IBodyElement mapValueData = (IBodyElement) entry.getValue();
			if(mapValueData instanceof XWPFParagraph) {
				XWPFParagraph paraObj = (XWPFParagraph)mapValueData;
				driver.doc.add(new Paragraph(paraObj.getParagraphText()));
			}
			if(mapValueData instanceof XWPFTable) {
				XWPFTable paraObj = (XWPFTable)mapValueData;
				driver.doc.add(new Paragraph(paraObj.getText()));
			}
		}
	}
		
		/*new KeyFeatures().Run(driver.doc);
		driver.doc.add(new AreaBreak(AreaBreakType.NEXT_PAGE));
		driver.doc.add(image);
		new Risks().Run(driver.doc);
		driver.doc.add(new AreaBreak(AreaBreakType.NEXT_PAGE));
		driver.doc.add(image);
		new Sales().Run(driver.doc);
		driver.doc.add(new AreaBreak(AreaBreakType.NEXT_PAGE));
		driver.doc.add(image);
		new Health().Run(driver.doc);
		driver.doc.add(new AreaBreak(AreaBreakType.NEXT_PAGE));
		driver.doc.add(image);
		new Milestones().Run(driver.doc);
		driver.doc.add(new AreaBreak(AreaBreakType.NEXT_PAGE));
		driver.doc.add(image);
		new LastPage().Run(driver.doc);*/
		driver.pdfDoc.close();
		driver.doc.close();
	}

}
