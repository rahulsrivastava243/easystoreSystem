package com.iris.controller;

public class MinuteHand implements TemporalHand {
	private int count = 0;
	private final TemporalHand observer;

	public MinuteHand(TemporalHand observer) {
		this.observer = observer;
	}

	@Override
	public void increment() {
		count++;
		if (count >= 60) {
			count = 0;
			observer.increment();
		}
	}

	@Override
	public void display() {
		System.out.println("minutes = " + count);
	}
}
