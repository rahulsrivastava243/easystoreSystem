package com.iris.controller;

public class ClockController {
	HourHand hourHand = new HourHand();
	MinuteHand minuteHand = new MinuteHand(hourHand);
	SecondHand secondHand = new SecondHand(minuteHand);
	private volatile boolean start = true;

	public void start() throws InterruptedException {
		while (start) {
			secondHand.increment();
			display();
			Thread.sleep(1000);
		}
	}

	public void stop() {
		start = false;
	}

	public void display() {
		hourHand.display();
		minuteHand.display();
		secondHand.display();
	}
	
	public static void main(String[] args) throws InterruptedException {
		ClockController clockController  = new ClockController();
		clockController.start();
		clockController.display();
		clockController.stop();
	}
}