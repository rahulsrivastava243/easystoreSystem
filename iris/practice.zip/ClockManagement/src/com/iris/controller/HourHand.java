package com.iris.controller;

public class HourHand implements TemporalHand {
	private int count = 0;

	@Override
	public void increment() {
		count++;
		if (count >= 24) {
			count = 0;
		}
	}

	@Override
	public void display() {
		System.out.println("hours = " + count);
	}
}