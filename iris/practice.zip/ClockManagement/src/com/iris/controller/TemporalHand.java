package com.iris.controller;

public interface TemporalHand {
	void increment();

	void display();
}