package com.iris.controller;

public class Slot {
	int slotid;
	int floorNo;
	boolean occupied;
	SlotSize size;
}