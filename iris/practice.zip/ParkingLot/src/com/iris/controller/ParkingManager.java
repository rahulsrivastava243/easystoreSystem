package com.iris.controller;

import java.util.HashMap;
import java.util.PriorityQueue;
import java.util.Queue;

public class ParkingManager {
	private Queue<Slot> slots = new PriorityQueue<>();
	private HashMap<Vehicle, Slot> parkDetail = new HashMap<Vehicle, Slot>();

public Slot getVehicle(String id) {...} // Logic for searching a vehicle using vehicle Id or slot id.

public Slot park(Vehicle vehicle) {...} // save the <vehicle - slot> mapping inside a hash table
}