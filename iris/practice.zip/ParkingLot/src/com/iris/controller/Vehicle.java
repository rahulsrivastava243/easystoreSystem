package com.iris.controller;

public class Vehicle {
	private String id;
	private String owner;
	private long mobile;
	private String inTime;
	private String outTime;
	private VehicleType vehicleType;
}