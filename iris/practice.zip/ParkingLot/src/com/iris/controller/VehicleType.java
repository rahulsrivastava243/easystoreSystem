package com.iris.controller;

public enum VehicleType {
	BIKE(new SlotSize(1), "Motor Bike"), CAR(new SlotSize(2), "Car"), TRUCK(new SlotSize(4), "Truck");
	private final ParkingSlotSize slotSize;
	private final String vehicleName;

private VehicleType(SlotSize slotSize, String vehicleName) {}
}