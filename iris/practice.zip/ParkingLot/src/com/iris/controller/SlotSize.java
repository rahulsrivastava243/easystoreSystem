package com.iris.controller;

public class SlotSize {
	private final int size;

	public SlotSize(int size) {
		this.size = size;
	}
}