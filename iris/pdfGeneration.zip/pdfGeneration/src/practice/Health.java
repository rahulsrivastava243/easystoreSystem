package practice;

import java.util.ArrayList;
import java.util.List;
import com.itextpdf.kernel.colors.DeviceCmyk;
import com.itextpdf.kernel.colors.DeviceRgb;
import com.itextpdf.kernel.colors.WebColors;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;

public class Health {
	public void Run(Document doc) throws Exception {
		new HealthPdf().createpdf(doc);
		new Health().manipulatePdf(doc);
	}

	protected void manipulatePdf(Document doc) throws Exception {
		Table table = new Table(5);
		HealthBean[] obj=getData();
		DeviceRgb myColor = WebColors.getRGBColor("#008000");
		for(int count=0;count<obj.length;count++){
			if (count % 2 == 0) {
				table.addCell(new Cell().add(new Paragraph(obj[count].getTrack())).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.3).setFontSize(10).setWidth(135));
				if(obj[count].getStatus()=='G'){
				Cell cell = new Cell().add(new Paragraph("G").setWidth(105).setFontSize(10));
				cell.setBackgroundColor(myColor);
				table.addCell(cell);	
				}
				else{
					table.addCell(new Cell().add(new Paragraph("Y")).setBackgroundColor(DeviceCmyk.YELLOW)
							.setFontSize(10).setWidth(105));
				}
				table.addCell(new Cell().add(new Paragraph(obj[count].getAccomplishment())).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.3).setFontSize(10).setWidth(185));
				table.addCell(new Cell().add(new Paragraph(obj[count].getNextMilestone())).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.3).setFontSize(10).setWidth(135));
				table.addCell(new Cell().add(new Paragraph(obj[count].getChallenges())).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.3).setFontSize(10).setWidth(135));
			}
			else{
				table.addCell(new Cell().add(new Paragraph(obj[count].getTrack())).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.1).setFontSize(10).setWidth(135));
				if(obj[count].getStatus()=='G'){
				Cell cell = new Cell().add(new Paragraph("G").setWidth(105).setFontSize(10));
				cell.setBackgroundColor(myColor);
				table.addCell(cell);	
				}
				else{
					table.addCell(new Cell().add(new Paragraph("Y")).setBackgroundColor(DeviceCmyk.YELLOW)
							.setFontSize(10).setWidth(105));
				}
				table.addCell(new Cell().add(new Paragraph(obj[count].getAccomplishment())).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.1).setFontSize(10).setWidth(185));
				table.addCell(new Cell().add(new Paragraph(obj[count].getNextMilestone())).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.1).setFontSize(10).setWidth(135));
				table.addCell(new Cell().add(new Paragraph(obj[count].getChallenges())).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.1).setFontSize(10).setWidth(135));
			}
		}
		doc.add(table);
	}
	public HealthBean[] getData() {
	 HealthBean[] obj=new HealthBean[2];
		obj[0]=new HealthBean();	
		obj[0].setTrack("Credit Risk Reporting");
		obj[0].setStatus('Y');
		obj[0].setAccomplishment("9 JIRA assigned for Nov release, 9 testing in progress-JIRA �C16153456609� and �C1615345-6275�: Issue in local jetty delayed the testing. Local jetty testing is in progress now.JIRA �C1615345-6846�: received changed request and code committed on 1st Nov. Testing in progress");
	    obj[0].setNextMilestone("Continue testing for November release JIRA");
	    obj[0].setChallenges("None");
	    obj[1]=new HealthBean();	
		obj[1].setTrack("CGS");
		obj[1].setStatus('G');
		obj[1].setAccomplishment("Estimates completed for 7 work items,Pending for 1 work items.FRD Review with BA for 1 WI�s  ,BAU4 production release: Timeline yet to be reviewed, earlier planned for Nov 17th. Per last communication production release is planned for Jan 5th,BAU 4 Prod support for defect fixing will be done by Iris team post Dec 31st (post Incumbent vendor support),Tech Mandatory activities gaps /activities -  Activities for tech mandatory initiated with Polaris Team (via screen sharing, lync, mail), Any build or deployment activity will be planned and done together by both teams mutually  through screen sharing � ETA � Dec 31st ,Automation testing demo to be planned with client by Nov 30th ,Testing on UAT for BAU 4 release - In Progress");
	    obj[1].setNextMilestone("Support BAU 4 production release,Initiate BAU5 activities");
	    obj[1].setChallenges("None");
	    return obj;
	}
}
