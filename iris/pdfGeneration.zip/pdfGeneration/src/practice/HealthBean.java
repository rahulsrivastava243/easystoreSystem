package practice;

public class HealthBean {
private String track;
private char status;
public String getTrack() {
	return track;
}
public void setTrack(String track) {
	this.track = track;
}
public char getStatus() {
	return status;
}
public void setStatus(char status) {
	this.status = status;
}
public String getChallenges() {
	return challenges;
}
public void setChallenges(String challenges) {
	this.challenges = challenges;
}
public String getNextMilestone() {
	return nextMilestone;
}
public void setNextMilestone(String nextMilestone) {
	this.nextMilestone = nextMilestone;
}
public String getAccomplishment() {
	return accomplishment;
}
public void setAccomplishment(String accomplishment) {
	this.accomplishment = accomplishment;
}
private String challenges;
private String nextMilestone;
private String accomplishment;
}
