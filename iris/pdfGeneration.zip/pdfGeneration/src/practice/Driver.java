package practice;

import java.io.File;

import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.AreaBreak;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.property.AreaBreakType;

public class Driver {

	public static final String DEST = "C:\\Users\\vaishali.gupta\\Desktop\\report.pdf";

	public static void main(String[] args) throws Exception {
		File file = new File(DEST);
		file.getParentFile().mkdirs();
		PdfWriter writer = new PdfWriter(DEST);
		PdfDocument pdfDoc = new PdfDocument(writer);
		Document doc = new Document(pdfDoc, PageSize.A4.rotate());
		String img = "./images/iris logo.png";
		Image image = new Image(ImageDataFactory.create(img));
		image.setHeight(50);
		image.setWidth(55);
		image.setFixedPosition(740, 550);
		doc.add(image);
		new FrontPage().Run(doc);
		doc.add(new AreaBreak(AreaBreakType.NEXT_PAGE));
		doc.add(image);
		new KeyFeatures().Run(doc);
		doc.add(new AreaBreak(AreaBreakType.NEXT_PAGE));
		doc.add(image);
		new Risks().Run(doc);
		doc.add(new AreaBreak(AreaBreakType.NEXT_PAGE));
		doc.add(image);
		new Sales().Run(doc);
		doc.add(new AreaBreak(AreaBreakType.NEXT_PAGE));
		doc.add(image);
		new Health().Run(doc);
		doc.add(new AreaBreak(AreaBreakType.NEXT_PAGE));
		doc.add(image);
		new Milestones().Run(doc);
		doc.add(new AreaBreak(AreaBreakType.NEXT_PAGE));
		doc.add(image);
		new LastPage().Run(doc);
		pdfDoc.close();
		doc.close();
	}

}
