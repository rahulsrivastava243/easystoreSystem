package practice;


public class RiskBean {
private String category;
private String track;
private String description;
private String owner;
private String actionPlan;
private String status;
private String identification;
private String target;
public String getCategory() {
	return category;
}
public void setCategory(String category) {
	this.category = category;
}
public String getTrack() {
	return track;
}
public void setTrack(String track) {
	this.track = track;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public String getOwner() {
	return owner;
}
public void setOwner(String owner) {
	this.owner = owner;
}
public String getActionPlan() {
	return actionPlan;
}
public void setActionPlan(String actionPlan) {
	this.actionPlan = actionPlan;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public String getIdentification() {
	return identification;
}
public void setIdentification(String identification) {
	this.identification = identification;
}
public String getTarget() {
	return target;
}
public void setTarget(String target) {
	this.target = target;
}


}
