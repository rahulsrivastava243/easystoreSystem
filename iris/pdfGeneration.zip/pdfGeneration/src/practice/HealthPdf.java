package practice;

import java.io.IOException;

import com.itextpdf.io.font.FontConstants;
import com.itextpdf.kernel.colors.DeviceCmyk;
import com.itextpdf.kernel.colors.DeviceRgb;
import com.itextpdf.kernel.colors.WebColors;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;

public class HealthPdf {
	public void createpdf(Document document) throws IOException {
		try {
			DeviceRgb myColor = WebColors.getRGBColor("#FF8C00");
			PdfFont bold = PdfFontFactory.createFont(FontConstants.TIMES_BOLD);
			document.add(new Paragraph("Track Health").setFontColor(myColor).setFont(bold).setFontSize(22)
					.setFixedPosition(30, 550, 800));
			document.add(new Paragraph());
			document.add(new Paragraph());
			document.add(new Paragraph());
			Table table = new Table(5);
			// table.setFixedPosition(30, 460, 560);
			table.addHeaderCell(new Cell().add(new Paragraph("Track")).setWidth(135).setBackgroundColor(DeviceCmyk.CYAN,
					(float) 0.7));
			table.addHeaderCell(new Cell().add(new Paragraph("Status")).setWidth(105)
					.setBackgroundColor(DeviceCmyk.CYAN, (float) 0.7));
			table.addHeaderCell(new Cell().add(new Paragraph("Accomplishments")).setWidth(185)
					.setBackgroundColor(DeviceCmyk.CYAN, (float) 0.7));
			table.addHeaderCell(new Cell().add(new Paragraph("Next Milestone(s)")).setWidth(135)
					.setBackgroundColor(DeviceCmyk.CYAN, (float) 0.7));
			table.addHeaderCell(new Cell().add(new Paragraph("Risks / Challenges")).setWidth(135)
					.setBackgroundColor(DeviceCmyk.CYAN, (float) 0.7));
			document.add(table);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
