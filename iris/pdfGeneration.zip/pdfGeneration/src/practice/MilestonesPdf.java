package practice;

import java.io.IOException;

import com.itextpdf.io.font.FontConstants;
import com.itextpdf.kernel.colors.DeviceCmyk;
import com.itextpdf.kernel.colors.DeviceRgb;
import com.itextpdf.kernel.colors.WebColors;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;

public class MilestonesPdf {
	public void createpdf(Document document) throws IOException {
		try {
			DeviceRgb myColor = WebColors.getRGBColor("#FF8C00");
			PdfFont bold = PdfFontFactory.createFont(FontConstants.TIMES_BOLD);
			document.add(new Paragraph("Milestones").setFont(bold).setFontSize(22).setFixedPosition(30, 550, 800)
					.setFontColor(myColor));
			document.add(new Paragraph());
			document.add(new Paragraph());
			document.add(new Paragraph());
			Table table = new Table(9);
			table.addHeaderCell(new Cell().add(new Paragraph("Track")).setWidth(85).setBackgroundColor(DeviceCmyk.CYAN,
					(float) 0.7));
			table.addHeaderCell(new Cell().add(new Paragraph("Milestones")).setWidth(95)
					.setBackgroundColor(DeviceCmyk.CYAN, (float) 0.7));
			table.addHeaderCell(new Cell().add(new Paragraph("Planned Start Date")).setWidth(85)
					.setBackgroundColor(DeviceCmyk.CYAN, (float) 0.7));
			table.addHeaderCell(new Cell().add(new Paragraph("Planned End Date")).setWidth(85)
					.setBackgroundColor(DeviceCmyk.CYAN, (float) 0.7));
			table.addHeaderCell(new Cell().add(new Paragraph("Actual Start Date")).setWidth(85)
					.setBackgroundColor(DeviceCmyk.CYAN, (float) 0.7));
			table.addHeaderCell(new Cell().add(new Paragraph("Actual End Date")).setWidth(85)
					.setBackgroundColor(DeviceCmyk.CYAN, (float) 0.7));
			table.addHeaderCell(new Cell().add(new Paragraph("Comment")).setWidth(85)
					.setBackgroundColor(DeviceCmyk.CYAN, (float) 0.7));
			table.addHeaderCell(new Cell().add(new Paragraph("% Complete")).setWidth(55)
					.setBackgroundColor(DeviceCmyk.CYAN, (float) 0.7));
			table.addHeaderCell(
					new Cell().add(new Paragraph("RAG")).setWidth(25).setBackgroundColor(DeviceCmyk.CYAN, (float) 0.7));
			// table.setWidth(PageSize.A4.getWidth());
			document.add(table);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}