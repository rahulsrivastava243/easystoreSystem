package practice;

import com.itextpdf.io.font.FontConstants;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.colors.DeviceRgb;
import com.itextpdf.kernel.colors.WebColors;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.element.Paragraph;

public class FrontPage {

	public void Run(Document doc) throws Exception {
		String img1 = "./images/logo1.png";
		Image image1 = new Image(ImageDataFactory.create(img1));
		image1.setHeight(450);
		image1.setWidth(110);
		image1.setFixedPosition(680, 50);
		doc.add(image1);
		new FrontPage().manipulatePdf(doc);
	}

	protected void manipulatePdf(Document doc) throws Exception {
		DeviceRgb myColor = WebColors.getRGBColor("000080");
		PdfFont bold = PdfFontFactory.createFont(FontConstants.TIMES_BOLD);
		doc.add(new Paragraph("CITI Account Status Report:  Nov 10th , 2017").setFont(bold).setFontSize(25)
				.setFixedPosition(100, 300, 500).setFontColor(myColor));
	}
}
