package practice;

import java.io.IOException;

import com.itextpdf.io.font.FontConstants;
import com.itextpdf.kernel.colors.DeviceRgb;
import com.itextpdf.kernel.colors.WebColors;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;

public class KeyFeatures {

	public void Run(Document doc) throws Exception {
		new KeyFeatures().createpdf(doc);
	}

	public void createpdf(Document doc) throws IOException {
		try {
			DeviceRgb myColor = WebColors.getRGBColor("#FF8C00");
			DeviceRgb bgColor = WebColors.getRGBColor("556b2f");
			DeviceRgb white = WebColors.getRGBColor("#ffffff");
			PdfFont font = PdfFontFactory.createFont(FontConstants.TIMES_ROMAN);
			PdfFont bold = PdfFontFactory.createFont(FontConstants.TIMES_BOLD);
			doc.add(new Paragraph("Executive Summary").setFont(bold).setFontSize(22).setFixedPosition(30, 550, 800)
					.setFontColor(myColor));
			doc.add(new Paragraph());
			doc.add(new Paragraph("Key Updates").setWidth(100).setBackgroundColor(bgColor, (float) 0.7).setFont(font)
					.setFontSize(18).setFontColor(white));
			doc.add(new Paragraph());
			doc.add(new Paragraph());
			doc.add(new Paragraph(
					"Citi-Received Additional 9 requirements on Microstrategy & BA  in Market Risk area.Plan to replace all the mobile tokens with Safenet physical tokens by end Dec.Need to replace 6 non-performers in the teams. Planning in-progress.")
							.setFontSize(10));
			doc.add(new Paragraph());
			doc.add(new Paragraph(
					"CGS-Estimates completed for 7 work items. Pending for 1 work items.FRD Review with BA for 1 WI�s .BAU4 production release: Timeline yet to be reviewed, earlier planned for Nov 17th. Per last communication production release is planned for Jan 5th.BAU 4 Prod support for defect fixing will be done by Iris team post Dec 31st (post Incumbent vendor support).Tech Mandatory activities gaps /activities -� Activities for tech mandatory initiated with Polaris Team (via screen sharing, lync, mail), Any build or deployment activity will be planned and done together by both teams mutually �through screen sharing � ETA � Dec 31st .Automation testing demo to be planned with client by Nov  30th .Testing on UAT for BAU 4 release  - In Progress")
							.setFontSize(10));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}