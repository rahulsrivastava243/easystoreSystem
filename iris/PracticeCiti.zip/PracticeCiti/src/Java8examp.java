import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Java8examp {

	public static void main(String[] args) {
		 List<Integer> contestents = new ArrayList<Integer>(8);
		    contestents.add(1);
		    contestents.add(2);
		    contestents.add(3);
		    contestents.add(4);
		    contestents.add(5);
		    contestents.add(6);
		    contestents.add(7);
		    contestents.add(8);
		    contestents.add(9);
		    
		    List<Integer> winners = contestents.stream().limit(5).collect(Collectors.toList());
		    System.out.println(winners.toString());
		    System.out.println(winners.stream().findFirst());
	}
}
