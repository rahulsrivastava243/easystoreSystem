import java.util.LinkedList;

public class Example2
{
	
	private static String a;
	
    public static void main(String[] args)
    {
       /*LinkedList<String> arrayList = new LinkedList<>();
       arrayList.add("A");
       System.out.println(arrayList.get(0));*/
    	
    	Example2 example21 = new Example2();
    	Example2 example22= new Example2();
    	Example2 example23= new Example2();
    	
    	example21.setName("example21");
    	
    	example22.printA();
    	example23.printA();
    	example23.setName("example23");    
    	example22.printA();
    	example21.printA();
    }
    
    
    public void setName(String q) {
    	a = q;
    	
    }
    
    public void printA() {
    	System.out.println(a);
    	
    }
}