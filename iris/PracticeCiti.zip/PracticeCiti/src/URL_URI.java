import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;

public class URL_URI {

	public static void main(String[] args) throws MalformedURLException, URISyntaxException {
		URL url = new URL("https://dzone.com/articles/java-collections?name=1234");
		System.out.println(url.getProtocol());
		System.out.println(url.getQuery());
		System.out.println(url.getQuery());
	}
}
