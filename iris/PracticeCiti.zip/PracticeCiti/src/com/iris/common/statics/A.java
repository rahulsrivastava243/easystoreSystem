package com.iris.common.statics;

import com.iris.string.StringTest;

public class A {
	
	public static void main(String[] args) {
		StringTest a = new StringTest();	
		System.out.println();
	}
}
