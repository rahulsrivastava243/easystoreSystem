package com.iris.common.statics;

public class StaticInInheritence {
	private static String value1;
	private static String value2;
	 static int a =10;
	
	static {
		System.out.println("static one");
		value1= "rahul";
		value2 = "rohit";
	}
	
	public void print() {
		System.out.println(this.a);
	}
	
	static {
		
		System.out.println("static two");
		value1= "sumit";
		value2 = "deepak";
	}
	
	{
		System.out.println("instance");
		value1= "sumit instance";
		value2 = "deepak instance";
	}
	
	public static void main(String[] args) {
		
	}
}
