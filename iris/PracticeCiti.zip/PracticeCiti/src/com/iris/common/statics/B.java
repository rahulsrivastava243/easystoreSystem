package com.iris.common.statics;

public class B extends A{
	
public static void test() {
	
	}


}
