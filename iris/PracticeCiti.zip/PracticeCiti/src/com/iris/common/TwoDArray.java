package com.iris.common;

public class TwoDArray {

	public static void main(String[] args) {
		int[][] test = { { 0, 1, 4, 5, 6, 8 }, 
                { 4, 5, 8, 3, 9 },
                { 3, 6, 2 } 
              };
		
		int maxcol = 0;
		for(int i = 0; i < test.length; i++)
		    if(test[i].length > maxcol)
		        maxcol = test[i].length;


		int[] result = new int[maxcol];

		for (int j = 0; j < maxcol; j++)
		    for (int i = 0; i < test.length; i++)
		        if (test[i].length > j && result[j] < test[i][j])
		            result[j] = test[i][j];
		
		
		for(int i = 0 ;i< result.length ; i++)
		System.out.println(result[i]);
	}

}
