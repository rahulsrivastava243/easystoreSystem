package com.iris.common;

public class StaticBlockTest {
	private static String value1;
	private static String value2;
	
	static {
		System.out.println("static one");
		value1= "rahul";
		value2 = "rohit";
	}
	
	static {
		System.out.println("static two");
		value1= "sumit";
		value2 = "deepak";
	}
	
	{
		System.out.println("instance");
		value1= "sumit instance";
		value2 = "deepak instance";
	}
	
	
	

	public static void main(String[] args) {
		System.out.println(value1);
		System.out.println(value2);
		new StaticBlockTest();
	}

}
