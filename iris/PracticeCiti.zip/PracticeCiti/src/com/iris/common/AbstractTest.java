package com.iris.common;

public final class AbstractTest {
	
	AbstractTest(){
		
	}
	
	final static int a;
	final static int b;
	static {
	a =10;
	b = 20;
	}
	
	public void show() {
	
		
	}
	
	 public class B{
		 protected B() {
			 
		 }
			
		}
		
		abstract class C extends B{
			
		}
		 class D{
			
		}
		
		class E{
			
		}
		
	
	

}
