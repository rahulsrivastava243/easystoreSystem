package com.iris.common;

public class ArrayStoreException {

	public static void main(String[] args) {
		Object[] stringArray = new String[5]; //No compile time error : String[] is auto-upcasted to Object[]
		stringArray[1] = "JAVA";
		stringArray[2] = 100;
	}
}
