package com.iris.common;

public class CountThenumberOfBit {

	public static void main(String[] args) {
		System.out.println(1&1);

	}

}
