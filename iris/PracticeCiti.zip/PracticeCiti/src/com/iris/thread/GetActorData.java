package com.iris.thread;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class GetActorData {

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		
		List<DataTask> list = new ArrayList<>();
		
		for(int i = 1 ; i<200;i++) {
			list.add(new DataTask("actor", i));
		}
	
		ExecutorService executorService = Executors.newFixedThreadPool(4);
		List<Future<Article>> articles  = executorService.invokeAll(list);
		
		for(Future<Article> future : articles) {
			System.out.println(future.get());
		}
		
		executorService.shutdown();
	}

}
