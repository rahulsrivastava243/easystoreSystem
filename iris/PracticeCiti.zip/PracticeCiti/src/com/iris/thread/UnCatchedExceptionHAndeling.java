package com.iris.thread;

import java.lang.Thread.UncaughtExceptionHandler;

public class UnCatchedExceptionHAndeling {
	
	
	public static void main(String[] args) {
Thread t = new Thread(new Runnable() {
			
			@Override
			public void run() {
				
				 System.out.println(Integer.parseInt("123"));
			      System.out.println(Integer.parseInt("234"));
			      System.out.println(Integer.parseInt("345"));
			      System.out.println(Integer.parseInt("XYZ")); //This will cause NumberFormatException
			      System.out.println(Integer.parseInt("456"));
			}
		});
		
t.setName("Thread1");

Thread t2 = new Thread(new Runnable() {
	
	@Override
	public void run() {
		throw new RuntimeException("Thread2");
	}
});

t2.setName("Thread1");

		UncaughtExceptionHandler s = new UncaughtExceptionHandler() {

		    public void uncaughtException(Thread t, Throwable e) {
		    	 System.out.printf("An exception has been captured\n");
		         System.out.printf("Thread: %s\n", t.getId());
		         System.out.printf("Exception: %s: %s\n", e.getClass().getName(), e.getMessage());
		         System.out.printf("Stack Trace: \n");
		         e.printStackTrace(System.out);
		         System.out.printf("Thread status: %s\n", t.getState());
		         t.start();
		    }
		};
		
		t.setUncaughtExceptionHandler(s);
		t2.setUncaughtExceptionHandler(s);
		
		t.start();
		t2.start();

	}
}
