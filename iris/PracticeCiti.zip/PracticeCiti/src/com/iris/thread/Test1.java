package com.iris.thread;

public class Test1 {
	
	public static void main(String[] args) {
		String s ="abc";
		System.out.println((s+s).contains("cba"));
	}

}
