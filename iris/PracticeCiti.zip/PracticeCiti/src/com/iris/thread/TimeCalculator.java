package com.iris.thread;

public class TimeCalculator extends Thread{
	
	private static String str = "a";
	
	@Override
	public void run() {
		
		System.out.println(Thread.currentThread().getName());
		synchronized (str) {
			System.out.println(Thread.currentThread().getName());
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("out  " + Thread.currentThread().getName());
	}
	

	public static void main(String[] args) throws InterruptedException {
		TimeCalculator t1 = new TimeCalculator();
		TimeCalculator t2 = new TimeCalculator();
		t1.run();
		str = "rahul";
		Thread.sleep(500);
		t2.run();

	}

}
