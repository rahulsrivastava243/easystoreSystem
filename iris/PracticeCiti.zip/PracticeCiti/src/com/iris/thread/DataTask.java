package com.iris.thread;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.concurrent.Callable;

public class DataTask implements Callable<Article>{
	
	
	
	private String tableName;
	private int id;
	static Connection con  = null;
	static Statement stmt = null;
	
	static {
		try {
			if(con == null) {
				System.out.println("#################################################");
			    Class.forName("com.mysql.jdbc.Driver");
				con= DriverManager.getConnection("jdbc:mysql://localhost:3306/sakila","root","root");
				
			}
		} catch (Exception e) {
		}  
	}
	
	public DataTask(String tableName,int id) {
		this.tableName = tableName;
		this.id = id;
		
		
	}
	
	@Override
	public Article call() throws Exception {
		
		Article article = null;;
		try {
			stmt=con.createStatement();  
			ResultSet rs=stmt.executeQuery("select * from "+ tableName +" where actor_id = " + id);  
			while(rs.next())  {
				article = new Article(rs.getInt("actor_id"), rs.getString("first_name"), rs.getString("last_name"));
			}
			Thread.sleep(200);
		} catch (Exception e) {
			e.printStackTrace();
		}  
		return article;
	}
	
	

}
