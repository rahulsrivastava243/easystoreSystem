package com.iris.thread;

import java.util.concurrent.atomic.AtomicInteger;

public class ThreeThreadsOrderedLockLess {

	AtomicInteger sharedOutput = new AtomicInteger(0);
    private Object object = new Object();
	public static void main(String[] args) {
		ThreeThreadsOrderedLockLess less = new ThreeThreadsOrderedLockLess();
		MyThread t1 = less.new MyThread(0);
		MyThread t2 = less.new MyThread(1);
		MyThread t3 = less.new MyThread(2);
		MyThread t4 = less.new MyThread(3);
		MyThread t5 = less.new MyThread(4);
		MyThread t6 = less.new MyThread(5);
		
		t1.setName("Thread1");
		t2.setName("Thread2");
		t3.setName("Thread3");
		t4.setName("Thread4");
		t5.setName("Thread5");
		t6.setName("Thread6");
		t1.start();
		t2.start();
		t3.start();
		t4.start();
		t5.start();
		t6.start();

	}
	
	 class MyThread extends Thread{
		private int finalPosition ;
		public MyThread(int threadPosition) {
			this.finalPosition = threadPosition;
		}
		
		@Override
		public void run() {
			while(sharedOutput.get() < 19) {
				if(sharedOutput.get() % 6 == this.finalPosition) {
				synchronized (object) {
						System.out.println(Thread.currentThread().getName() + " "+ sharedOutput.getAndIncrement());
					}
				}
				
				
			}
		}
		 
	}

}
