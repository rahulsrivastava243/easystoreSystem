package com.iris.thread;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class MapTest {



	public static void main(String[] args) {
		Map<String,String> concurrentHashMap = new ConcurrentHashMap()	;
		
		System.out.println(5 >> 3 );

		new Thread() {
			
			public void run() {
				int i = 0;
				while(i < 100)
				{
					System.out.println(i);
					concurrentHashMap.put(""+1, ""+i);
					i++;
				}
			};
		}.start();
		
new Thread() {
			
			public void run() {
				int i = 0;
				while(i < 100)
				{
					System.out.println("Get --"+concurrentHashMap.get(""+1));
					i++;
				}
			};
		}.start();
new Thread() {
			
			public void run() {
				int i = 0;
				while(i < 100)
				{
					System.out.println("Get 2--"+concurrentHashMap.get(""+1));
					i++;
				}
			};
		}.start();

		

	}
}
