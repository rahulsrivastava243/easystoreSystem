package com.iris.file;

public abstract class Test123 {

	private Test123() {
		
	}
	
public Test123(int i) {
		
	}
	
}
