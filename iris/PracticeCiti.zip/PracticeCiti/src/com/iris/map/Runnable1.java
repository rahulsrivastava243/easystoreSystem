package com.iris.map;

import java.util.concurrent.Semaphore;

public class Runnable1 implements Runnable{
	
	Semaphore semaphore1 ;
	Semaphore semaphore2 ;
	Semaphore semaphore3 ;
	
	public Runnable1(Semaphore semaphore1,Semaphore semaphore2,Semaphore semaphore3) {
		this.semaphore1 = semaphore1;
		this.semaphore2 = semaphore2;
		this.semaphore3 = semaphore3;
	}

	@Override
	public void run() {
		try {
			semaphore1.acquire();
			System.out.println(Thread.currentThread().getName());
			semaphore2.release();
		} catch (InterruptedException e) {
			
		}
		
		
	}

}
