package com.iris.map;

import java.util.concurrent.Semaphore;

public class Runnable2 implements Runnable{

	Semaphore semaphore1 ;
	Semaphore semaphore2 ;
	Semaphore semaphore3 ;
	
	public Runnable2(Semaphore semaphore1,Semaphore semaphore2,Semaphore semaphore3) {
		this.semaphore1 = semaphore1;
		this.semaphore2 = semaphore2;
		this.semaphore3 = semaphore3;
	}
	
	@Override
	public void run() {
		try {
			semaphore2.acquire();
			System.out.println(Thread.currentThread().getName());
			semaphore3.release();
		} catch (InterruptedException e) {
			
		}
		
	}

}
