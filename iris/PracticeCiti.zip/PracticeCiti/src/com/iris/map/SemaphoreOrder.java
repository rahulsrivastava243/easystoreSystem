package com.iris.map;

import java.util.concurrent.Semaphore;

public class SemaphoreOrder {
	
	
	
	public static void main(String[] args) {
		Semaphore semaphore1 = new Semaphore(1);
		Semaphore semaphore2 = new Semaphore(0);
		Semaphore semaphore3 = new Semaphore(0);
		
		Thread thread1 = new Thread(new Runnable1(semaphore1, semaphore2, semaphore3),"thread1");
		Thread thread2 = new Thread(new Runnable2(semaphore1, semaphore2, semaphore3),"thread2");
		Thread thread3 = new Thread(new Runnable3(semaphore1, semaphore2, semaphore3),"thread3");
        
		thread1.start();
		thread2.start();
		thread3.start();

	}

}
