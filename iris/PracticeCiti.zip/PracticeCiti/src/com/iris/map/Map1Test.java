package com.iris.map;

public class Map1Test {

	public static void main(String[] args) {
		System.out.println(add());
	}
	
	public static String add() {
		try {
			System.out.println("try");
			return "try";
		}
		catch(Exception e) {
			return "catch";
		}
		finally {
			return "finally";
		}
	}

}
