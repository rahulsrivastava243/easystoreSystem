package com.iris.map;

import java.util.HashMap;
import java.util.Map;

public class MapTest {

	public static void main(String[] args) {
		Map<Employee,String> map = new HashMap<>();
		Employee emp = new Employee(20,"rahul");
		map.put(emp , "Rahul");
		emp.setName("sumit");
		Employee emp1 = new Employee(20,"rahul1");
		map.put(emp1 , "Rahul");
		System.out.println(map.get(emp1));
		System.out.println(map.size());
		
	}

}
