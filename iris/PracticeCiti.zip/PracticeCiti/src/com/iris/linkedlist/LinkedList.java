package com.iris.linkedlist;

public class LinkedList {
	
	protected Node first;
	protected Node last;
	protected int size;
	
	
	public LinkedList() {
		this.first = null;
		this.last = null;
		size = 0;
	}
	
	public boolean isEmplty() {
		return size == 0;
	}
	
	
	public void add(Integer value) {
		if(value == null) {
			throw new NullPointerException();
		}
		if(isEmplty()) {
			Node prev = last;
			last = new Node(value,null);
			prev.next = last;
		}
		else {
			last = new Node(value,null);
			first = last;
		}
		size++;
	}
	
	public void display() {
		while(first.next != null) {
			System.out.println(first.getData());
		}
	}
	
	public static void main(String[] args) {
		LinkedList list = new LinkedList();
		list.add(12);
		list.add(16);
		list.add(20);
		list.display();
	}
	

}
