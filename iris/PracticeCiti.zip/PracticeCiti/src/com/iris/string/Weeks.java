package com.iris.string;

public enum Weeks {
	
	
	MONDAY,TUSEDAY,WEDNESDAY,THRUSDAY,FRIDAY,SATURDAY,SUNDAY;
	

}
