package com.iris.string;

public class StringTest {
	
//	@Override
//	protected Object clone() throws CloneNotSupportedException {
//		// TODO Auto-generated method stub
//		return super.clone();
//	}
	
	public static void main(String[] args) throws CloneNotSupportedException,ArithmeticException,Exception {
		String s = new String("rahul");
		
		try {
			int a = 10/0;
		}
		catch(ArithmeticException e) {
			throw new ArithmeticException(); 
		}
		catch(Exception e) {
			throw new Exception(); 
		}
	}

}
