package com.iris.string;

public class WeekSort {

	public static void main(String[] args) {
		String[] w = {};
		for(Weeks day : Weeks.values()) {
			System.out.println(day.name());
		}
	}
}
