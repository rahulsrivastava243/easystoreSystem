package coml.iris.inheritance;

public class B extends A{
	
	B(){
		System.out.println("B()");
	}

}
