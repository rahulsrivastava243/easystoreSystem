package coml.iris.inheritance;

public class C extends B{
	
	C(){
		System.out.println("C()");
	}

}
