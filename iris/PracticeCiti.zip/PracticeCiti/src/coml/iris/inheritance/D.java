package coml.iris.inheritance;

public class D extends C{

	D(){
		System.out.println("D()");
	}
	
	public static void main(String[] args) {
		new D();
	}
}
