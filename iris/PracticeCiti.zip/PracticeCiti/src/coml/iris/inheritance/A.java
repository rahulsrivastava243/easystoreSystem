package coml.iris.inheritance;

public class A {

	A(){
		System.out.println("A()");
	}
}
